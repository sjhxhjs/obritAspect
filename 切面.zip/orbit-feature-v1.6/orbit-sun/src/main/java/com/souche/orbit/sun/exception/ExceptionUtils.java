package com.souche.orbit.sun.exception;

import com.souche.optimus.common.util.Exceptions;
import com.souche.optimus.exception.OptimusExceptionBase;
import lombok.extern.slf4j.Slf4j;

/**
 * @author SuperDaFu
 * @date 2018/10/10 下午4:39
 */
@Slf4j
public class ExceptionUtils {

    public static OptimusExceptionBase fail(Throwable e) {
        return fail(500001, e);
    }

    public static OptimusExceptionBase fail(String errMsg) {
        return fail(500001, errMsg, null);
    }

    /**
     * 占位符 {}
     */
    public static OptimusExceptionBase fail(String errMsg, Object... args) {
        final String replace = errMsg.replaceAll("\\{\\}", "%s");
        String msg = String.format(replace, args);
        return fail(msg);
    }

    public static OptimusExceptionBase fail(String errMsg, Throwable e, Object... args) {
        final String replace = errMsg.replaceAll("\\{\\}", "%s");
        String msg = String.format(replace, args);
        return fail(msg, e);
    }

    public static OptimusExceptionBase fail(String errMsg, Throwable throwable) {
        return fail(500001, errMsg, throwable);
    }

    public static OptimusExceptionBase fail(int code, Throwable throwable) {
        if (throwable == null) {
            return fail(code, "系统异常", throwable);
        } else {
            return fail(code, throwable.getMessage(), throwable);
        }
    }

    public static OptimusExceptionBase fail(int code, String errmsg, Throwable throwable) {
        //业务异常
        log.error("Throw Exception: code:{},errmsg:{}", code, errmsg, throwable);
        final OptimusExceptionBase fail = Exceptions.fail(String.valueOf(code), errmsg);
        return fail;
    }

    public static OptimusExceptionBase fault(Throwable throwable) {
        return fault("500002", throwable);
    }

    public static OptimusExceptionBase fault(String code, Throwable throwable) {
        return fault(code, "系统内部异常", throwable);
    }

    public static OptimusExceptionBase fault(String code, String errmsg, Throwable throwable) {
        //系统异常
        log.error("Throw Exception: code:{},errmsg:{}", code, errmsg, throwable);
        return fault(code, throwable);
    }

}
