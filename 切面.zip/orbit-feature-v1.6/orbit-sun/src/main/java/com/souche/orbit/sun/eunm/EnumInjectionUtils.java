package com.souche.orbit.sun.eunm;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;
import com.google.common.collect.Maps;
import com.souche.optimus.common.page.Page;
import com.souche.optimus.common.util.StringUtil;
import com.souche.orbit.sun.eunm.behavior.EnumInjectBehavior;
import com.souche.orbit.sun.utils.ReflectionUtils;

/**
 * @author SuperDaFu
 * @date 2019/3/14 下午4:57
 */
@Component
@Slf4j
public class EnumInjectionUtils implements ApplicationContextAware {

    private static Map<String, Object> injectBehaviorMap = new ConcurrentHashMap<>();
    
    private static final ThreadLocal<Map<String,Object>> infos =  new ThreadLocal<Map<String,Object>>();

    public static Object getValue(String key){
        if (com.souche.optimus.common.util.CollectionUtils.isEmpty(infos.get())) {
            return null;
        }
        return infos.get().get(key);
    }
    
    private static void setValue(String key,Object value) {
        if (com.souche.optimus.common.util.CollectionUtils.isEmpty(infos.get())) {
            infos.set(Maps.newConcurrentMap());
        }
        infos.get().put(key, value);
    }
    
    private static void clearInfos() {
        infos.remove();
    }
    
    public static void parseInjectClass(Object result, EnumInjection enumInjection) {
        Class<?> clazz = enumInjection.clazz();
        parseInjectClass(result, clazz);
        clearInfos();
    }


    public static void parseInjectClass(Object result, Class clazz) {
        if (null == clazz) {
            return;
        }
        if (clazz.isAssignableFrom(result.getClass())) {
            inject(result, clazz);
        } else if (result instanceof List<?>) {
            List<?> list = (List<?>) result;
            for (Object obj : list) {
                inject(obj, clazz);
            }
        } else if (result instanceof Page<?>) {
            Page<?> page = (Page<?>) result;
            List<?> list = page.getItems();
            if (CollectionUtils.isNotEmpty(list)) {
                for (Object obj : list) {
                    inject(obj, clazz);
                }
            }
        }
    }

    /**
     * 枚举值注入
     */
    private static void inject(Object result, Class<?> clazz) {
        Field[] fields = clazz.getDeclaredFields();
        for (Field field : fields) {
            EnumInjection annotation = field.getAnnotation(EnumInjection.class);
            if (annotation != null) {
                Object re = null;
                Method getter = ReflectionUtils.getGetter(clazz, field.getName(), false);
                try {
                    re = getter.invoke(result, new Object[]{});
                } catch (Exception e) {
                    log.error("method:{} invoke error", getter.getName(), e);
//                    throw new OptimusExceptionBase("枚举反射异常");
                    continue;
                }
                if (re == null) {
                    continue;
                }
                parseInjectClass(re, annotation);
            } else {
                //单个枚举信息注入
                EnumValue enumValue = field.getAnnotation(EnumValue.class);
                if (null == enumValue) {
                    continue;
                }
                String relateCode = enumValue.relateCode();
                Method getter = ReflectionUtils.getGetter(clazz, relateCode, false);
                Object relateCodeValue = null;
                try {
                    relateCodeValue = getter.invoke(result, new Object[]{});
                } catch (Exception e) {
                    log.error("method:{} invoke error", getter.getName(), e);
//                    throw new OptimusExceptionBase("枚举反射异常");
                    continue;
                }
                if (null == relateCodeValue) {
                    continue;
                }

                Class<? extends EnumInjectBehavior> aClass = enumValue.enumInjectBehavior();
                if (aClass == null) {
                    continue;
                }
                EnumInjectBehavior behavior = (EnumInjectBehavior) injectBehaviorMap.get(aClass.getName());
                if (behavior == null) {
                    if (context != null) {
                        EnumInjectBehavior bean = context.getBean(aClass);
                        if (bean != null) {
                            behavior = bean;
                            injectBehaviorMap.put(aClass.getName(), behavior);
                        }
                    }
                }
                if (behavior == null) {
                    return;
                }
                
                //临时存储数据
                setValue(enumValue.relateCode(), relateCodeValue);
                
                String value = behavior.getValue(enumValue, relateCodeValue);
                if (StringUtil.isEmpty(value)) {
                    continue;
                }
                Method setter = ReflectionUtils.getSetter(clazz, field.getName(), false);
                try {
                    setter.invoke(result, value);
                } catch (Exception e) {
                    log.error("method:{} invoke error", setter.getName(), e);
//                    throw new OptimusExceptionBase("枚举反射异常");
                    continue;
                }

            }
        }
    }

    private static ApplicationContext context;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        EnumInjectionUtils.context = applicationContext;
    }
}
