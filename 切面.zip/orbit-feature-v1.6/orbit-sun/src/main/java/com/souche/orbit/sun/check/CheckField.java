package com.souche.orbit.sun.check;

import java.io.Serializable;
import java.lang.reflect.Method;

/**
 * @author wdf
 */
public class CheckField implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    /**
     * 字段名
     */
    private String fieldName;
    
    /**
     * field的值
     */
    private Object value;
    
    /**
     * 该字段对应的class
     */
    private Class<?> cls;

    private Method getMethod;

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public Object getValue() {
        return value;
    }

    public void setValue(Object value) {
        this.value = value;
    }

    public Class<?> getCls() {
        return cls;
    }

    public void setCls(Class<?> cls) {
        this.cls = cls;
    }

    public Method getGetMethod() {
        return getMethod;
    }

    public void setGetMethod(Method getMethod) {
        this.getMethod = getMethod;
    }
    
    

}
