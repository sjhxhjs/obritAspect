package com.souche.orbit.sun.search.remote;

import com.souche.elastic.search.common.SearchQuery;
import com.souche.orbit.sun.search.dto.SearchQueryDTO;
import com.souche.orbit.sun.search.dto.SearchResponseDTO;
import org.apache.commons.lang3.tuple.Pair;

/**
 * @author SuperDaFu
 * @date 2018/5/2 上午10:34
 */
public interface SearchSPI {

    Pair<SearchResponseDTO,Throwable> query(SearchQueryDTO query);

    Pair<SearchResponseDTO, Throwable> query(SearchQuery searchQuery);
}
