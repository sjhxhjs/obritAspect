package com.souche.orbit.sun.dto;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.wordnik.swagger.annotations.ApiModelProperty;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import lombok.Data;

/**
 * 前端是用的 键值对对象
 * @author SuperDaFu
 * @date 2018/4/28 下午2:42
 */
@Data
public class KVDTO {
    @ApiModelProperty("状态值 key")
    private String key;
    @ApiModelProperty("对应的value")
    private String value;
    //前端显示的值
    @ApiModelProperty("前端显示值")
    private String label;
    //拓展信息
    private JSONObject extendsInfo;

    public KVDTO(String key,String value){
        this.key = key;
        this.value= value;
    }
    public KVDTO (){

    }

    public static List<KVDTO> convertFromMap(Map<String, String> maps) {
        List<KVDTO> result = Lists.newLinkedList();
        maps.forEach((s, s2) -> {
            KVDTO kvdto = new KVDTO();
            kvdto.setKey(s);
            kvdto.setValue(s);
            kvdto.setLabel(s2);
            result.add(kvdto);
        });
        return result;
    }

}
