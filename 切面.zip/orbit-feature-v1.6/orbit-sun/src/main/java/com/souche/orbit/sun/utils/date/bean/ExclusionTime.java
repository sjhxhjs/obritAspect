package com.souche.orbit.sun.utils.date.bean;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ExclusionTime {
    
    private long startTime;
    
    private long endTime;
    
}
