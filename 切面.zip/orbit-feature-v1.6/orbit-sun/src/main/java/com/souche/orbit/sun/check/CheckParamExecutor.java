package com.souche.orbit.sun.check;

import com.google.common.collect.Maps;
import com.souche.optimus.common.util.StringUtil;
import com.souche.orbit.sun.OrbitSunConstant;
import com.souche.orbit.sun.eunm.BasicEnumToDictionary;
import com.souche.orbit.sun.exception.OrbitExceptionBase;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

/**
 * 校验
 */
@Slf4j
public class CheckParamExecutor {


    private CheckModeRegister checkModeRegister;

    /**
     * 缓存正则表达式编译对象
     */
    private final Map<String, Pattern> regexPattern = Maps.newConcurrentMap();

    /**
     * 校验对象参数
     */
    public void checkParamBasic(Object obj) {

        if (obj == null) {
            return;
        }

        if (obj instanceof List) {
            List list = (List) obj;
            for (Object o : list) {
                checkObj(o);
            }
        } else {
            checkObj(obj);
        }

    }

    public void checkObj(Object obj) {
        if (obj == null) {
            return;
        }
        Class<? extends Object> cls = obj.getClass();

        List<CheckField> checkFields = new ArrayList<CheckField>();

        Map<String, CheckField> nameSet = new HashMap<String, CheckField>();

        while (cls.getSuperclass() != null) {
            Method[] methods = cls.getDeclaredMethods();
            Field[] fields = cls.getDeclaredFields();
            for (Method method : methods) {
                String methodName = method.getName();
                if (methodName.startsWith("get") || methodName.startsWith("is")) {
                    String fieldName = methodName.replaceAll("^get|^is", "");
                    if (StringUtil.isEmpty(fieldName)) {
                        continue;
                    }
                    if (method.getParameterTypes().length != 0) {
                        continue;
                    }

                    fieldName = Character.toLowerCase(fieldName.charAt(0)) + fieldName.substring(1);

                    CheckField checkField = nameSet.get(fieldName);

                    if (checkField != null) {
                        log.info("Repeating field : {}", fieldName);
                        continue;
                    }

                    checkField = new CheckField();

                    checkField.setCls(method.getReturnType());
                    checkField.setGetMethod(method);
                    checkField.setFieldName(fieldName);
                    checkFields.add(checkField);

                    nameSet.put(fieldName, checkField);
                }
            }

            for (Field field : fields) {
                if (Modifier.isStatic(field.getModifiers())) {
                    continue;
                }
                String fieldName = field.getName();
                CheckField checkField = nameSet.get(fieldName);
                if (checkField == null) {
                    continue;
                }

                CheckParam checkParam = field.getAnnotation(CheckParam.class);

                field.setAccessible(true);
                Object value = null;
                try {
                    value = field.get(obj);
                } catch (Exception e) {
                    log.error("field to value error!", e);
                }
                checkValue(checkParam, value, field.getName());
            }
            cls = cls.getSuperclass();
        }
    }

    public void checkValue(CheckParam checkParam, Object value, String fieldName) {
        if (checkParam == null) {
            return;
        }

        String errMsg = StringUtil.isEmpty(checkParam.errMsg()) ? "字段" + fieldName : checkParam.errMsg();

        //必填参数校验
        if (checkParam.required()) {
            //空则抛出异常
            if (value == null || value.equals("")) {
                throw new OrbitExceptionBase(errMsg + "【不能为空】");
            }
        } else if (value == null || value.equals("")) {
            //如果非必填则跳出
            return;
        }

        String vStr = value == null ? "" : String.valueOf(value);

        //字符串 指定长度
        if (checkParam.length() > 0) {
            CheckMode checkMode = checkModeRegister.getCheckMode(OrbitSunConstant.CHECK_MODE_STR_LENGTH);
            if (!executorCheckMode(value, checkParam, checkMode, errMsg)) {
                return;
            }
        }
        //字符串 长度范围
        if (org.apache.commons.lang3.StringUtils.isNotEmpty(checkParam.lengthRange())) {
            CheckMode checkMode = checkModeRegister.getCheckMode(OrbitSunConstant.CHECK_MODE_STR_LENGTH_RANGE);
            if (!executorCheckMode(value, checkParam, checkMode, errMsg)) {
                return;
            }
        }
        //数值 大小限制
        if (org.apache.commons.lang3.StringUtils.isNotEmpty(checkParam.range())) {
            CheckMode checkMode = checkModeRegister.getCheckMode(OrbitSunConstant.CHECK_MODE_NUMBER_RANGE);
            if (!executorCheckMode(value, checkParam, checkMode, errMsg)) {
                return;
            }
        }
        //枚举校验
        if (StringUtil.isNotEmpty(checkParam.enumKey())
            && BasicEnumToDictionary.basicDic.get(checkParam.enumKey()) != null
            && StringUtil.isEmpty(BasicEnumToDictionary.basicDic.get(checkParam.enumKey()).get(vStr))) {
            throw new OrbitExceptionBase(errMsg + "【枚举类型异常】");
        }

        //正则表达式验证
        if (!StringUtils.isEmpty(checkParam.regex())) {
            Pattern pattern = getPattern(checkParam.regex());
            Matcher matcher = pattern.matcher(vStr);
            if (!matcher.matches()) {
                throw new OrbitExceptionBase(errMsg + "[格式异常]");
            }
        }
        String[] modes = checkParam.checkByModes();
        for (String mode : modes) {
            CheckMode checkMode = checkModeRegister.getCheckMode(mode);
            if (!executorCheckMode(value, checkParam, checkMode, errMsg)) {
                return;
            }
        }

    }

    private boolean executorCheckMode(Object value, CheckParam checkParam, CheckMode checkMode,String errorMsg) {
        if (checkMode == null) {
            throw new OrbitExceptionBase("checkMode未找到" + errorMsg);
        }
        boolean check = checkMode.check(value, checkParam);
        if (!check) {
            checkMode.error(value, errorMsg+"");
        }
        return check;
    }
    private Pattern getPattern(String regex) {
        Pattern pattern = regexPattern.get(regex);
        if (pattern == null) {
            pattern = Pattern.compile(regex);
            regexPattern.put(regex, pattern);
        }
        return pattern;
    }

    /**
     * 可以传入注解进行参数校验
     */
    public void checkParam(String paramName, Object arg, CheckParam checkParam) {
        if (arg == null) {
            return;
        }
        if (checkParam == null) {
            checkParamBasic(arg);
        } else {
            //checkParam不为null，checkparam已经是指定到了字段上，直接开始校验值
            checkValue(checkParam, arg, null);
        }

    }

    public void setCheckModeRegister(CheckModeRegister checkModeRegister) {
        this.checkModeRegister = checkModeRegister;
    }
    public void addCheckMode(String key, CheckMode checkMode){
        this.checkModeRegister.addCheckMode(key, checkMode);
    }
}
