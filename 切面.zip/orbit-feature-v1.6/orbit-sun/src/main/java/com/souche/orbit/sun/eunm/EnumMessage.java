package com.souche.orbit.sun.eunm;

/**
 * @author SuperDaFu
 * @date 2018/9/7 上午10:52
 */
public interface EnumMessage {

    /**
     * 该枚举名称
     * @return
     */
    String getCode();

    /**
     * 该枚举显示名称,更具Version实现不同版本输出不同name
     * @return
     */
    String getDisplayName();


}
