package com.souche.orbit.sun.check.modes;

import com.souche.orbit.sun.check.CheckMode;
import com.souche.orbit.sun.check.CheckParam;
import com.souche.orbit.sun.exception.ExceptionUtils;
import com.souche.orbit.sun.utils.RangeStrUtils;
import java.math.BigDecimal;

/**
 * @author SuperDaFu
 * @date 2018/9/21 上午10:56
 */
public class StringLengthRangeCheckMode implements CheckMode {

    @Override
    public boolean check(Object value, CheckParam checkParam) {
        String lengthRange = checkParam.lengthRange();
        String vStr = value == null ? "" : String.valueOf(value);
        return RangeStrUtils.checkRange(lengthRange, new BigDecimal(vStr.length()));
    }

    @Override
    public void error(Object value, String defaultErrorMsg) {
        throw ExceptionUtils.fail(defaultErrorMsg + " [字符串长度超出范文]");
    }
}
