package com.souche.orbit.sun.auth;

import com.souche.bumblebee.trace.SoucheTracer;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

/**
 * @author SuperDaFu
 * @date 2018/12/26 下午4:30
 */
@Component
@Slf4j
public class AuthInfoHolder implements ApplicationListener<ContextRefreshedEvent> {


    private static AuthInfoHolderActuotar authInfoHolderActuotar;

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        if (event.getApplicationContext().getParent() == null)
        //root application context 没有parent，他就是老大.
        {
        log.info("AuthInfoHolder 初始化AuthInfo");
            synchronized (this) {

                final AuthInfoHolderActuotar authInfoHolderActuotar = event.getApplicationContext()
                    .getBean("authInfoHolderActuotar", AuthInfoHolderActuotar.class);
                AuthInfoHolder.authInfoHolderActuotar = authInfoHolderActuotar;
            }

        }

    }

    public static void put(Map<String, String> map) {
        log.debug("AuthInfoHolder 放入用户信息 ;{}",map);
        authInfoHolderActuotar.put(map);
    }

    public static void addKV(String key, String value) {
        authInfoHolderActuotar.addKV(key, value);
    }
    public static void clear(){
        authInfoHolderActuotar.clear();
    }

    public static String getTraceId() {
        return SoucheTracer.getInstance().getTraceId();
    }

    /**
     * 登录用户的ID
     */
    public static String userId() {
        return authInfoHolderActuotar.userId();
    }

    /**
     * 获取登录用户的账号
     */
    public static String userName() {
        return authInfoHolderActuotar.userName();
    }

    /**
     * 获取登录用户的显示名
     */
    public static String displayName() {
        return authInfoHolderActuotar.displayName();
    }

    /**
     * 获取登录的用户手机
     */
    public static String userPhone() {
        return authInfoHolderActuotar.userPhone();
    }

    /**
     * 获取用户头像
     */
    public static String headImg() {
        return authInfoHolderActuotar.headImg();
    }


    public static String get(String key){
        return authInfoHolderActuotar.get(key);
    }

}
