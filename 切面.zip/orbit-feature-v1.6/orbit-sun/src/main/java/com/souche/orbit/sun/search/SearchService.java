package com.souche.orbit.sun.search;

import com.souche.elastic.search.common.Facet;
import com.souche.optimus.common.page.Page;
import com.souche.orbit.sun.search.dto.SearchQueryDTO;
import com.souche.orbit.sun.search.dto.SearchResponseDTO;
import java.util.List;

/**
 * @author SuperDaFu
 * @date 2018/5/3 上午10:57
 */
public interface SearchService {

    <E> List<E> searchList(SearchQueryDTO searchQuery, Class<? extends E> cls);

    <E> Page<E> searchPage(SearchQueryDTO searchQueryDTO, Class<? extends E> cls, Integer currentIndex,
        Integer pageSize);

    <E> Page<E> convertPage(SearchResponseDTO response, Class<? extends E> cls, Integer currentIndex,
        Integer pageSize,Throwable e);
    /**
     * 获取总数
     */
    Integer searchCount(SearchQueryDTO dto);


    /**
     * 设置不同索引 独有的各自属性
     * 这是searchQuery的基本属性 报错indexName
     * @param searchQueryDTO
     * @return
     */
    SearchQueryDTO getSearchQuery(SearchQueryDTO searchQueryDTO);

    List<Facet> searchAggregate(SearchQueryDTO searchQueryDTO);
}
