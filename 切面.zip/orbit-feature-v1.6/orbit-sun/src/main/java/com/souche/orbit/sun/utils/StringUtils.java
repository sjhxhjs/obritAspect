package com.souche.orbit.sun.utils;

import com.souche.optimus.common.util.StringUtil;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author SuperDaFu
 * @date 2018/5/3 下午4:55
 */
public class StringUtils extends org.apache.commons.lang.StringUtils{

    private StringUtils() {
    }

    private static final String SPECIAL_REGEX = "[`~!@#$%％^&*()+=|{}':;',//[//].<>/?~！@#￥%……&*（）——+|{}【】《》‘；：”“’。，、？ ]";
    
    
    public static String valueOf(Object obj){
        if(obj != null){
            return String.valueOf(obj);
        }
        return null;
    }
    
    
    /**
     * 将字符串转换成小写
     * @param str
     * @return
     */
    public static String toLowerCase(String str){
        if(StringUtil.isEmpty(str)){
            return str;
        }
        return str.toLowerCase();
    }
    
    /**
     * 将字符串转换成大写
     * @param str
     * @return
     */
    public static String toUpperCase(String str){
        if(StringUtil.isEmpty(str)){
            return str;
        }
        return str.toUpperCase();
    }
    
    /**
     * 判断是否含有特殊字符
     *
     * @param str
     * @return true为包含，false为不包含
     */
    public static boolean isSpecialChar(String str) {
        if(StringUtil.isEmpty(str)){
            return false;
        }
        Pattern p = Pattern.compile(SPECIAL_REGEX);
        Matcher m = p.matcher(str);
        return m.find();
    }
    
    /**
     * 驼峰写法转换成下划线
     * @param camel
     * @return
     */
    public static String camelToUnderline(String camel){
        if(StringUtil.isEmpty(camel))
        {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for(int i=0;i<camel.length();i++) {
            char c = camel.charAt(i);
            if(Character.isUpperCase(c))
            {
                sb.append("_").append(Character.toLowerCase(c));
            }else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    public static boolean isEmpty(String s) {
        return s == null || s.trim().length() == 0;
    }
    
    public static boolean hasEmpty(String... strs) {
        for(String s : strs){
            if(!isEmpty(s)){
                return false;
            }
        }
        return true;
    }
}
