package com.souche.orbit.sun.search;

import com.google.common.collect.Lists;
import com.souche.elastic.search.common.Facet;
import com.souche.optimus.common.page.Page;
import com.souche.orbit.sun.search.dto.SearchQueryDTO;
import com.souche.orbit.sun.search.dto.SearchResponseDTO;
import com.souche.orbit.sun.search.remote.SearchSPI;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author SuperDaFu
 * @date 2018/5/3 上午10:20
 */
public abstract class BaseSearchService implements SearchService {

    private static final Logger LOGGER = LoggerFactory.getLogger(BaseSearchService.class);


    @Resource(name = "searchSPI")
    public SearchSPI searchSPI;

    @Override
    public <E> List<E> searchList(SearchQueryDTO searchQuery, Class<? extends E> cls) {
        Pair<SearchResponseDTO, Throwable> query = searchSPI.query(getSearchQuery(searchQuery));
        SearchResponseDTO left = query.getLeft();
        if (left != null) {
            return left.getData(cls);
        } else {
            LOGGER.info("搜索出错 param->{},exception->{}", searchQuery, query.getRight());
            return Lists.newArrayList();
        }
    }

    @Override
    public <E> Page<E> searchPage(SearchQueryDTO searchQueryDTO, Class<? extends E> cls, Integer currentIndex,
        Integer pageSize) {
        searchQueryDTO.setCurrentIndex(currentIndex);
        searchQueryDTO.setPageSize(pageSize);
        SearchQueryDTO searchQuery = getSearchQuery(searchQueryDTO);
        Pair<SearchResponseDTO, Throwable> query = searchSPI.query(searchQuery);
        SearchResponseDTO left = query.getLeft();
        return convertPage(left, cls, currentIndex, pageSize, query.getRight());
    }

    @Override
    public <E> Page<E> convertPage(SearchResponseDTO left, Class<? extends E> cls, Integer currentIndex,
        Integer pageSize, Throwable e) {
        if (left != null) {
            List<E> data = left.getData(cls);
            Page<E> page = new Page<>(left.getTotal(), currentIndex, pageSize, data);
            //当存在distinctCount 属性值，直接覆盖数据总条目数
            final Long distinctTotal = left.getDistinctTotal();
            if (distinctTotal != null&&distinctTotal!=0) {
                page.setTotalNumber(Math.toIntExact(distinctTotal));
            }
            return page;
        } else {
            LOGGER.info("搜索出错 param->{},exception->{}", left, e);
            return new Page<>(0, currentIndex, pageSize, Lists.newArrayList());
        }
    }


    @Override
    public Integer searchCount(SearchQueryDTO dto) {
        dto.setCurrentIndex(0);
        dto.setPageSize(1);
        Pair<SearchResponseDTO, Throwable> query = searchSPI.query(getSearchQuery(dto));
        if (query.getLeft() != null) {
            return query.getLeft().getTotal();
        } else {
            LOGGER.info("搜索出错 param->{},exception->{}", dto, query.getRight());
        }
        return 0;
    }

    @Override
    public List<Facet> searchAggregate(SearchQueryDTO searchQueryDTO) {
        SearchQueryDTO searchQuery = getSearchQuery(searchQueryDTO);
        searchQuery.setPageSize(0);
        Pair<SearchResponseDTO, Throwable> query = searchSPI.query(searchQuery);
        if (query.getLeft() != null) {
            return query.getLeft().getAgg();
        } else {
            return new ArrayList<>();
        }
    }
}
