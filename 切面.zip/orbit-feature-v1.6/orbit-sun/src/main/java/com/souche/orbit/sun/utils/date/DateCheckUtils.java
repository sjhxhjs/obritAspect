package com.souche.orbit.sun.utils.date;

import com.souche.optimus.common.util.StringUtil;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author SuperDaFu
 * @date 2019/2/20 上午10:11
 */
public class DateCheckUtils {

    private final static Pattern patternDateRange = Pattern
        .compile("^\\d{4}/\\d{2}/\\d{2}\\s?\\-\\s?\\d{4}/\\d{2}/\\d{2}$");
    private final static Pattern patternDateRangeMax = Pattern.compile("^\\-\\s?\\d{4}/\\d{2}/\\d{2}$");

    //验证日期格式
    public static boolean isDate(String dateStr) {
        if (StringUtil.isEmpty(dateStr)) {
            return false;
        }
        return checkDate(dateStr, "yyyy-MM-dd");
    }

    public static boolean isDateTime(String dateStr) {
        if (StringUtil.isEmpty(dateStr)) {
            return false;
        }
        return checkDate(dateStr, "yyyy-MM-dd HH:mm");
    }

    private static boolean checkDate(String dateStr, String format) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
        try {
            // 设置lenient为false. 否则SimpleDateFormat会比较宽松地验证日期，比如2007/02/29会被接受，并转换成2007/03/01
            simpleDateFormat.setLenient(false);
            Date parse = simpleDateFormat.parse(dateStr);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    /**
     * 检查是不是一个时间段
     */
    public static boolean isDateRange(String dateStr) {
        if (StringUtil.isEmpty(dateStr)) {
            return false;
        }
        Matcher m = patternDateRange.matcher(dateStr);
        final boolean matches = m.matches();
        if (matches) {
            return matches;
        }
        return patternDateRangeMax.matcher(dateStr).matches();
    }
}
