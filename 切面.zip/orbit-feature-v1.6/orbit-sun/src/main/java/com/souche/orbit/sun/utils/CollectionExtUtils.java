package com.souche.orbit.sun.utils;

import org.apache.commons.collections.CollectionUtils;

/**
 * @author SuperDaFu
 * @date 2019/5/22 上午8:25
 */
public class CollectionExtUtils extends CollectionUtils {

}
