package com.souche.orbit.sun.search.annotation;

import com.souche.orbit.sun.search.SearchConstants.SearchType;
import com.souche.orbit.sun.search.eunm.FilterDirEnum;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 对于索引搜索，进行一定的自定义动作
 *
 * @author SuperDaFu
 * @date 2018/5/7 下午3:47
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface SearchParam {

    /**
     * 是否忽略这个字段
     */
    boolean ignore() default false;

    /**
     * 该字段在 搜索动作中的参数类型
     *
     * keyword 需要保证QuerySearchDTO为设置keyword，否则会忽略这个值
     *
     */
    String type() default SearchType.AND;

    /**
     * 时间区间，是否包含末尾那一天
     * @return
     */
    boolean includeEndDay() default true;

    /**
     * 该字段放入搜索后的key, 多个字段使用 ','分割
     */
    String label() default "";

    /**
     * 筛选的 不等式方向
     * @return
     */
    FilterDirEnum filterDir() default FilterDirEnum.FILTER_DIR_NONE;

}
