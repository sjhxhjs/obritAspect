package com.souche.orbit.sun.eunm.feature;

/**
 * @author SuperDaFu
 * @date 2018/10/11 下午3:23
 */
public interface EnumChangeName extends EnumVersion {

    String getChangeName(Integer version);
}
