package com.souche.orbit.sun.utils;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import com.souche.optimus.common.util.CollectionUtils;

/**
 * 排序工具类
 * @author jinrenhua
 * @date 2019年3月17日 上午10:53:06
 */
@Slf4j
public class SortUtil {
    
    /**
     * 拼音首字母排序
     * @param objects
     * @param sortField
     * @return
     */
    public static <T> List<T> sortChinesPinyin(List<T> objects, String sortField){
        
        if(CollectionUtils.isEmpty(objects)){
            return objects;
        }
        
        Collections.sort(objects,new Comparator<T>(){
            @Override
            public int compare(T o1, T o2) {
                
                String pinyin1 = PinyinUtil.getChinesPinyin(ObjectUtils.getFieldStringValueByName(sortField, o1));
                String pinyin2 = PinyinUtil.getChinesPinyin(ObjectUtils.getFieldStringValueByName(sortField, o2));
                
                int re = pinyin1.compareToIgnoreCase(pinyin2);
                
                if( re == 0) return 0;
                
                if( re > 0 ) return 1;
                
                return -1;
            }
            
        });
        
        return objects;
    }
    
    
    
}
