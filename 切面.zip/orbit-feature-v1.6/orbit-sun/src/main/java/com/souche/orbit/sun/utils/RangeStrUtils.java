package com.souche.orbit.sun.utils;

import com.souche.orbit.sun.exception.ExceptionUtils;
import java.math.BigDecimal;
import java.util.regex.Pattern;
import lombok.Data;
import org.apache.commons.lang.StringUtils;

/**
 * 检查范围设定字符串是否合法
 *
 * @author SuperDaFu
 * @date 2018/9/21 上午10:58
 */
public class RangeStrUtils {

    private static Pattern pattern = Pattern.compile("^[\\(\\[]\\d* ?, ?\\d*[\\)\\]]$");

    public static boolean checkRangeStr(String range) {
        if (StringUtils.isEmpty(range)) {
            return false;
        }
        return pattern.matcher(range).matches();
    }

    public static RangeInfo parseRange(String rangeStr) {
        String replace = rangeStr.replace(" ", "");
        char start = replace.charAt(0);
        char end = replace.charAt(replace.length() - 1);
        RangeInfo result = new RangeInfo();
        if ('(' == start) {
            result.setHaveLeft(false);
        } else {
            result.setHaveLeft(true);
        }
        if (')' == end) {
            result.setHaveRight(false);
        } else {
            result.setHaveRight(true);
        }

        String[] split = (replace.substring(1, replace.length() - 1)).split(",");
        if (split.length != 2) {
            String temp = split[0];
            split = new String[]{temp,""};
        }
        if (!StringUtils.isEmpty(split[0])) {
            result.setMin(new BigDecimal(split[0]));
        }
        if (!StringUtils.isEmpty(split[1])) {
            result.setMax(new BigDecimal(split[1]));
        }
        return result;
    }

    public static boolean checkRange(String rangeStr, BigDecimal value) {
        boolean b = checkRangeStr(rangeStr);
        if (b) {
            RangeInfo rangeInfo = parseRange(rangeStr);
            if (rangeInfo.getMax() != null) {
                if (rangeInfo.haveRight) {
                    if (value.compareTo(rangeInfo.getMax()) > 0) {
                        return false;
                    }
                } else {
                    if (value.compareTo(rangeInfo.getMax()) != -1) {
                        return false;
                    }
                }
            }
            if (null != rangeInfo.getMin()) {
                if (rangeInfo.haveLeft) {
                    if (value.compareTo(rangeInfo.getMin()) < 0) {
                        return false;
                    }
                }else {
                    if (value.compareTo(rangeInfo.getMin()) != 1) {
                        return false;
                    }
                }
            }
            return true;
        } else {
            throw ExceptionUtils.fail("range格式非法：" + rangeStr);
        }
    }

    @Data
    public static class RangeInfo {

        private BigDecimal min;
        private BigDecimal max;
        private boolean haveLeft;
        private boolean haveRight;
    }
}
