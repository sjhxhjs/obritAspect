package com.souche.orbit.sun.utils;

import com.souche.optimus.common.util.StringUtil;
import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.net.JarURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ClassLoaderUtil {
    
    
    
    /**
     * 添加clsaa到List
//     * @param packagePath xx/xx/xx/ 允许用. 或者 /
     * @param packageName com.souche.xxx 必须以.
     * @return
     */
    public static List<Class> getClass( String packageName) {
        
        List<Class> clszzs = new ArrayList<Class>();
        
        try {
            String packageDirName = packageName.replace(".", "/");
            Enumeration<URL> urls = getClassLoader().getResources(packageDirName);

            while (urls.hasMoreElements()) {

                URL url = urls.nextElement();

                if (url != null) {

                    String protocol = url.getProtocol();

                    if (protocol.equals("file")) {
                        // 转码
                        String packagePath = URLDecoder.decode(url.getFile(), "UTF-8");
                        addClass(clszzs, packagePath, packageName);

                    } else if (protocol.equals("jar")){
                        addClass(clszzs, url, packageName, packageDirName);
                    }

                }

            }

        } catch (Exception e) {
            log.error("查找包下的类失败{}", e);
        }
        
        return clszzs;
    }
    
    /**
     * 子目录加载
     * @param clszzs
     * @param packagePath
     * @param packageName
     */
    private static void addClass(List<Class> clszzs, String packagePath, String packageName) {
         
        File[] files = new File(packagePath).listFiles(new FileFilter() {

            @Override
            public boolean accept(File file) {
                return (file.isFile() && file.getName().endsWith(".class") || file.isDirectory());
            }
        });

        for (File file : files) {

            String fileName = file.getName();

            if (file.isFile()) {
                String className = fileName.substring(0, fileName.lastIndexOf("."));

                if (StringUtil.isNotEmpty(packageName)) {

                    className = packageName + "." + className;
                    log.error("className: {}", className);
                }
                // 添加
                doAddClass(clszzs, className);
            } else {
                // 子目录
                String subPackagePath = fileName;
                if (StringUtil.isNotEmpty(packagePath)) {
                    subPackagePath = packagePath + "/" + subPackagePath;
                }

                String subPackageName = fileName;
                if (StringUtil.isNotEmpty(packageName)) {
                    subPackageName = packageName + "." + subPackageName;
                }

                addClass(clszzs, subPackagePath, subPackageName);
            }
        }

    }
    
    
    /**
     * 添加class
     * @param clszzs
     * @param className
     */
    private static void doAddClass(List<Class> clszzs, String className) {

        Class<?> cls = loadClass(className, false);
        clszzs.add(cls);
    }
    
    
    /**
     * 加载类
     * 需要提供类名与是否初始化的标志，
     * 初始化是指是否执行静态代码块
     * @param  className
     * @param  isInitialized  为提高性能设置为false
     * @return Class<?>    返回类型
     */
    public static Class<?> loadClass(String className, boolean isInitialized) {

        Class<?> cls;
        try {
            cls = Class.forName(className, isInitialized, getClassLoader());
            return cls;
        } catch (ClassNotFoundException e) {
            log.error("加载类失败 loadClass->{}", e);
        }

        return null;
    }
    
    /**
     * 获取类加载器
     * @return ClassLoader    
     */
    public static ClassLoader getClassLoader() {

        return Thread.currentThread().getContextClassLoader();
    }

    public static void addClass(List<Class> clazzs, URL url, String packageName, String packageDirName){
        JarFile jar;
        try {
            // 获取jar
            jar = ((JarURLConnection) url.openConnection())
                    .getJarFile();
            // 从此jar包 得到一个枚举类
            Enumeration<JarEntry> entries = jar.entries();
            // 同样的进行循环迭代
            while (entries.hasMoreElements()) {
                // 获取jar里的一个实体 可以是目录 和一些jar包里的其他文件 如META-INF等文件
                JarEntry entry = entries.nextElement();
                String name = entry.getName();
                // 如果是以/开头的
                if (name.charAt(0) == '/') {
                    // 获取后面的字符串
                    name = name.substring(1);
                }
                // 如果前半部分和定义的包名相同
                if (name.startsWith(packageDirName)) {
                    int idx = name.lastIndexOf('/');
                    // 如果以"/"结尾 是一个包
                    if (idx != -1) {
                        // 获取包名 把"/"替换成"."
                        packageName = name.substring(0, idx)
                                .replace('/', '.');

                        // 如果是一个.class文件 而且不是目录
                        if (name.endsWith(".class")
                                && !entry.isDirectory()) {
                            // 去掉后面的".class" 获取真正的类名
                            String className = name.substring(
                                    packageName.length() + 1, name
                                            .length() - 6);
                            try {
                                // 添加到classes
                                clazzs.add(Class
                                        .forName(packageName + '.'
                                                + className));
                            } catch (ClassNotFoundException e) {
                                e.printStackTrace();
                                // log
                                // .error("添加用户自定义视图类错误 找不到此类的.class文件");
                            }
                        }
                    }
                }
            }
        } catch (IOException e) {
            // log.error("在扫描用户定义视图时从jar包获取文件出错");
        }
    }

}
