package com.souche.orbit.sun.utils;

import java.util.HashMap;
import java.util.Map;
import com.souche.orbit.sun.utils.StringUtils;
import lombok.extern.slf4j.Slf4j;
import net.sourceforge.pinyin4j.PinyinHelper;
import net.sourceforge.pinyin4j.format.HanyuPinyinCaseType;
import net.sourceforge.pinyin4j.format.HanyuPinyinOutputFormat;
import net.sourceforge.pinyin4j.format.HanyuPinyinToneType;
import net.sourceforge.pinyin4j.format.HanyuPinyinVCharType;
import net.sourceforge.pinyin4j.format.exception.BadHanyuPinyinOutputFormatCombination;

/**
 * 拼音工具类
 * @author jinrenhua
 * @date 2019年3月17日 上午10:53:17
 */
@Slf4j
public class PinyinUtil {

    private static HanyuPinyinOutputFormat hanYuPinOutputFormat = new HanyuPinyinOutputFormat(); 
    private static Map<String,String> staticChars = new HashMap<String,String>();
    
    static{
        //输出设置，大小写，音标方式等 
        hanYuPinOutputFormat.setCaseType(HanyuPinyinCaseType.LOWERCASE);   
        hanYuPinOutputFormat.setToneType(HanyuPinyinToneType.WITHOUT_TONE); 
        hanYuPinOutputFormat.setVCharType(HanyuPinyinVCharType.WITH_V);  
        
    }
    
    
    public static String getChinesPinyin(String code){
        
        if(StringUtils.isEmpty(code)) return null;
        
        char[] codeChar = code.toCharArray();
        
        StringBuilder sb = new StringBuilder();
        
        for(char c : codeChar){
            
            // 是中文或者a-z或者A-Z转换拼音
            if (String.valueOf(c).matches("[\\u4E00-\\u9FA5]+")) {
                try {
                    
                    String key = String.valueOf(c);

                    if(staticChars.containsKey(key)){
                        sb.append(staticChars.get(key));
                        continue;
                    }
                    
                    String[]  pins = PinyinHelper.toHanyuPinyinStringArray(c, hanYuPinOutputFormat);
                    
                    if(pins != null && pins.length > 0){
                        sb.append(pins[0]);
                    }
                    
                } catch (BadHanyuPinyinOutputFormatCombination e) {
                    log.error("PinyinUtil.getChinesPinyin error!",e);
                }
            } else if (((int) c >= 65 && (int) c <= 90)
                    || ((int) c >= 97 && (int) c <= 122)) {
                sb.append(String.valueOf(c));
            }else{
                sb.append(String.valueOf(c));
            }
            
        }
        
        return sb.toString();
    }
}
