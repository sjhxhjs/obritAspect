package com.souche.orbit.sun.utils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.souche.optimus.common.util.StringUtil;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;

/**
 * 排序字段解析
 * @author SuperDaFu
 * @date 2018/6/28 上午10:45
 */
@Slf4j
public class SortMappingUtils {

    public static String frontMapping(String frontValue) {
        if (StringUtil.isEmpty(frontValue)) {
            return null;
        }
        switch (frontValue) {
            case "ascending":
                return "ASC";
            case "descending":
                return "DESC";
            default:
                return null;
        }
    }
    /**
     * 解析前端排序字段，
     * sort =[{prop:"accidentDate",order:"descending"}]
     *
     * @param sortArraystr  jsonarray字符串
     * @return
     */
    public static Map<String, String> parseOrderList(String sortArraystr) {
        Map<String,String> sort = Maps.newLinkedHashMap();
        try {
            JSONArray sortArray = JSONArray.parseArray(sortArraystr);
            for (int i = 0; i < sortArray.size(); i++) {
                JSONObject jsonObject = sortArray.getJSONObject(i);
                String prop = StringUtils.camelToUnderline(jsonObject.getString("prop"));
                String order = frontMapping(jsonObject.getString("order"));
                if (!StringUtil.isAnyEmptyNew(prop, order)) {
                    sort.put(prop, order);
                }
            }
        } catch (Exception e) {
            log.warn("索引 排序 查询解析错误 {}", sortArraystr,e);
        }
        return sort;
    }
}
