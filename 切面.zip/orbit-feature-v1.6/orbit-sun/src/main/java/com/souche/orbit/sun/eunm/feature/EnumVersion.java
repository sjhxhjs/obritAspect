package com.souche.orbit.sun.eunm.feature;

/**
 * @author SuperDaFu
 * @date 2018/10/11 下午3:24
 */
public interface EnumVersion {


    /**
     * 枚举输出版本，使用二进制进行管理
     * @return
     */
    Integer getVersion();


}
