package com.souche.orbit.sun.search.dto;

import com.souche.elastic.search.common.ESSearchResponse;
import com.souche.elastic.search.common.Facet;
import java.util.List;

/**
 * @author SuperDaFu
 * @date 2018/5/2 上午10:44
 */
public class SearchResponseDTO<T> {

    private ESSearchResponse result;

    public SearchResponseDTO(ESSearchResponse result) {
        this.result = result;
    }

    public List<T> getData(Class<T> t) {
        return result.getDocItems(t);
    }

    public Integer getTotal() {
        return result.getTotal();
    }

    public List<Facet> getAgg() {
        return result.getAgg();
    }

    public Long getDistinctTotal() {
        return result.getDistinctCount();
    }
}
