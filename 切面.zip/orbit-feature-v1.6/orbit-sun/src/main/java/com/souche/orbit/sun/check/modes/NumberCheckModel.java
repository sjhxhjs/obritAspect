package com.souche.orbit.sun.check.modes;

import com.souche.orbit.sun.check.CheckMode;
import com.souche.orbit.sun.check.CheckParam;
import com.souche.orbit.sun.exception.ExceptionUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * 检查一个字符串是不是一个数字
 * @author SuperDaFu
 * @date 2018/11/27 上午11:30
 */
public class NumberCheckModel implements CheckMode {

    @Override
    public boolean check(Object o, CheckParam checkParam) {
        String s = o == null ? "" : String.valueOf(o);
        return StringUtils.isNumeric(s);
    }

    @Override
    public void error(Object o, String s) {
        throw ExceptionUtils.fail(s + " [字段非数字]");
    }
}
