package com.souche.orbit.sun.dao;

import com.souche.optimus.common.vo.BaseVo;

/**
 * 默认的字段填充器
 * 创建者 修改者 时间等等
 *
 * @author SuperDaFu
 * @date 2019/2/21 下午4:42
 */
public interface DaoFieldApplider {

    <T extends BaseVo> void onUpdate(T t);

    <T extends BaseVo> void onInsert(T t);
}
