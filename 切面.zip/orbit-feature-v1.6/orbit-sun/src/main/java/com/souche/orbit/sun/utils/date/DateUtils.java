package com.souche.orbit.sun.utils.date;

import com.souche.optimus.exception.OptimusExceptionBase;
import com.souche.orbit.sun.exception.ExceptionUtils;
import com.souche.orbit.sun.utils.StringUtils;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.Objects;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author SuperDaFu
 * @date 2018/5/15 下午8:22
 */
public class DateUtils {

    private final static Logger LOGGER = LoggerFactory.getLogger(DateUtils.class);

    /**
     * 与当前时间进行比较
     *
     * @return true:比当前时间达，false:比当前时间小
     */
    public static boolean compareDateToNow(Date date) {

        long compareResult = compareDate(date, new Date());

        if (compareResult > 0) {
            return true;
        }

        return false;
    }
    
    /**
     * 校验是否是当天
     * @param date
     * @return
     */
    public static boolean checkInTheDay(Date date){
        return checkInTheDay(date, new Date());
    }
    /**
     * 校验是否是当天
     * @param date
     * @return
     */
    public static boolean checkInTheDay(Date date,Date now){
        if(date == null){
            return false;
        
        }
        return Objects.equals(formatDate(now,"yyyy-MM-dd"), formatDate(date, "yyyy-MM-dd"));
        
    }

    /**
     * 比较2个时间
     *
     * @return true : d1 > d2
     */
    public static boolean compareTime(Date d1, Date d2) {

        long compareResult = compareDate(d1, d2);

        if (compareResult > 0) {
            return true;
        }

        return false;
    }

    /**
     * 比较2个data 返回时间戳
     */
    public static long compareDate(Date d1, Date d2) {

        if (d1 == null || d2 == null) {
            return 0L;
        }

        return d1.getTime() - d2.getTime();
    }

    /**
     * 比较2个data
     *
     * @return last date
     */
    public static Date compareLastDate(Date d1, Date d2) {
        if (d1 == null) {
            return d2;
        }
        if (d2 == null) {
            return d1;
        }
        if (d1.getTime() > d2.getTime()) {
            return d1;
        }
        return d2;
    }

    public static String getNowReadDateTime() {
        String nowTime = null;

        try {
            Date rightNow = new Date();
            DateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            nowTime = format1.format(rightNow);
        } catch (Exception var3) {
            nowTime = "";
        }

        return nowTime;
    }

    public static String getNowReadDate() {
        String nowTime = null;

        try {
            Date rightNow = new Date();
            DateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
            nowTime = format1.format(rightNow);
        } catch (Exception var3) {
            nowTime = "";
        }

        return nowTime;
    }


    public static int getDay(Date date) {
        Calendar instance = Calendar.getInstance();
        instance.setTime(date);
        return instance.get(Calendar.DATE);
    }

    /**
     * Date转换String
     */
    public static String parseDate(Date date, String format) {
        if (date == null) {
            return "";
        }
        SimpleDateFormat sm = new SimpleDateFormat(format);
        return sm.format(date);
    }

    /**
     * 生成时间
     */
    public static Date strToDate(String formate, String date) {
        try {
            SimpleDateFormat f = new SimpleDateFormat(formate);
            return f.parse(date);
        } catch (Exception e) {
            return null;
        }
    }
    
    /**
     * 生成时间戳
     */
    public static Long strToTimeMillis(String formate, String date) {
        try {
            SimpleDateFormat f = new SimpleDateFormat(formate);
            return f.parse(date).getTime();
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 计算两日期之间天数,向上取整 from-to
     */
    public static int minus(Date from, Date to) {
        return Math.abs(minusReal(from, to));
    }

    public static int minusReal(Date from, Date to) {
        long fromTime = clearHMS(from).getTime();
        long toTime = clearHMS(to).getTime();
        long diffTime = fromTime - toTime;
        double days = (double) diffTime / (1000 * 60 * 60 * 24);
        return (int) Math.ceil(days);
    }

    public static String getMonthStartDateStr(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String format = sdf.format(getMonthStartDate(date).getTime());
        return format;
    }

    public static Date getMonthStartDate(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        return clearHMS(calendar.getTime());
    }

    public static String getNextMonthStartDateStr(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String format = sdf.format(getNextMonthStartDate(date));
        return format;
    }

    /**
     * 下个月，一号的时间
     */
    public static Date getNextMonthStartDate(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.MONTH, 1);
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        return clearHMS(calendar.getTime());
    }

    /**
     * 获取一个月结束的日期
     */
    public static Date getMonthEndDate(Date date) {
        return add(getNextMonthStartDate(date), -1, Calendar.DATE);
    }

    /**
     * 获取一个月份的总天数
     */
    public static int getMonthDayCount(Date date) {
        Calendar instance = Calendar.getInstance();
        instance.setTime(date);
        int actualMaximum = instance.getActualMaximum(Calendar.DAY_OF_MONTH);
        return actualMaximum;
    }


    /**
     * 上个月，相同天数的日期
     */
    public static Date getPreMonthSameDate(Date date) {
        Calendar instance = Calendar.getInstance();
        instance.setTime(date);
        int i = instance.get(Calendar.DATE);
        instance.set(Calendar.DATE, 1);
        instance.add(Calendar.MONTH, -1);
        int monthDayCount = getMonthDayCount(instance.getTime());
        if (monthDayCount <= i) {
            i = monthDayCount;
        }
        instance.set(Calendar.DATE, i);
        return instance.getTime();
    }

    /**
     * 解析时间范围
     */
    public static Date[] parseDateRange(String dateRangeStr) {
        if (DateCheckUtils.isDateRange(dateRangeStr)) {
            String s = dateRangeStr.replaceAll(" ", "");
            String[] split = s.split("-");
            if (split.length != 2) {
                return null;
            }
            Date[] result = new Date[2];
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd");
            try {
                if (!StringUtils.isEmpty(split[0])) {
                    result[0] = simpleDateFormat.parse(split[0]);
                }
                if (!StringUtils.isEmpty(split[1])) {
                    result[1] = simpleDateFormat.parse(split[1]);
                }
                return result;
            } catch (ParseException e) {
                LOGGER.info("解析时间出错 dateStr->{}", dateRangeStr);
                return null;
            }
        }
        return null;
    }

    /**
     * @param date 需要处理的时间
     * @param amount 值
     * @param type 需要添加的字段
     */
    public static Date add(Date date, int amount, int type) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(type, amount);
        return calendar.getTime();
    }

    public static String add(Date date, int i, int type, String format) {
        Date add = add(date, i, type);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
        return simpleDateFormat.format(add);
    }

    /**
     * 计算需要处理的 月份有多少个
     */
    public static int minusMonth(Date startDate, Date endDate) {
        //endDate 为 2017-01-01  也就是数据库里面是date 格式的时候，取出的值 后面会报错
        startDate = new Date(startDate.getTime());
        endDate = new Date(endDate.getTime());
        if (startDate.getTime() > endDate.getTime()) {
            throw new OptimusExceptionBase("结束时间小于开始时间");
        }
        startDate = getNextMonthStartDate(startDate);
        endDate = getNextMonthStartDate(endDate);
        Instant instant = endDate.toInstant();
        long between = ChronoUnit.MONTHS.between(LocalDateTime.ofInstant(startDate.toInstant(), ZoneId.systemDefault()),
            LocalDateTime.ofInstant(instant, ZoneId.systemDefault()));
        return Math.toIntExact(between) + 1;
    }

    /**
     * 计算两个时间内的季度间隔数目(从一开始，用来计算账单数目)
     */
    public static int minusQuarter(Date startDate, Date endDate) {
        if (startDate.getTime() > endDate.getTime()) {
            throw new OptimusExceptionBase("结束时间小于开始时间");
        }
        Calendar start = Calendar.getInstance();
        Calendar end = Calendar.getInstance();
        start.setTime(startDate);
        start.set(Calendar.DAY_OF_MONTH, 1);
        end.setTime(endDate);
        int minus = 0;
        while (start.compareTo(end) == -1) {
            start.add(Calendar.MONTH, minus == 0 ? 2 : 3);
            start.set(Calendar.DAY_OF_MONTH, start.getActualMaximum(Calendar.DAY_OF_MONTH));
            minus++;
        }
        return minus;
    }

    /**
     * 计算两个时间内的半年间隔数目(从一开始，用来计算账单数目)
     */
    public static int minusHalfYear(Date startDate, Date endDate) {
        if (startDate.getTime() > endDate.getTime()) {
            throw new OptimusExceptionBase("结束时间小于开始时间");
        }
        Calendar start = Calendar.getInstance();
        Calendar end = Calendar.getInstance();
        start.setTime(startDate);
        start.set(Calendar.DAY_OF_MONTH, 1);
        end.setTime(endDate);
        int minus = 0;
        while (start.compareTo(end) == -1) {
            start.add(Calendar.MONTH, minus == 0 ? 5 : 6);
            start.set(Calendar.DAY_OF_MONTH, start.getActualMaximum(Calendar.DAY_OF_MONTH));
            minus++;
        }
        return minus;
    }

    /**
     * 计算两个时间内的年间隔数目(从一开始，用来计算账单数目)
     */
    public static int minusYear(Date startDate, Date endDate) {
        if (startDate.getTime() > endDate.getTime()) {
            throw new OptimusExceptionBase("结束时间小于开始时间");
        }
        Calendar start = Calendar.getInstance();
        Calendar end = Calendar.getInstance();
        start.setTime(startDate);
        end.setTime(endDate);
        int minus = 0;
        while (start.compareTo(end) == -1) {
            start.add(Calendar.YEAR, 1);
            if (minus == 0) {
                start.add(Calendar.MONTH, -1);
            }
            start.set(Calendar.DAY_OF_MONTH, start.getActualMaximum(Calendar.DAY_OF_MONTH));
            minus++;
        }
        return minus;
    }

    /**
     * 清除时分秒
     */
    public static Date clearHMS(Date paymentDate) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String format = simpleDateFormat.format(paymentDate);
        try {
            return simpleDateFormat.parse(format);
        } catch (ParseException e) {
            return paymentDate;
        }
    }

    /**
     * 添加i个月份
     */
    public static Date addMonth(Date date, int i) {
        Calendar instance = Calendar.getInstance();
        instance.setTime(date);
        instance.add(Calendar.MONTH, i);
        return instance.getTime();
    }

    /**
     * 格式化时间
     */
    public static String formatDate(Date ddate, String format) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
        String result = simpleDateFormat.format(ddate);
        return result;
    }
    
    /**
     * 格式化时间
     */
    public static String formatDate(long t, String format) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
        String result = simpleDateFormat.format(t);
        return result;
    }

    /**
     * 比较两个时间的相隔时间
     */
    public static int minusHour(Date start, Date end) {
        if (end.before(start)) {
            ExceptionUtils.fail("时间错误");
        }
        long startTime = start.getTime();
        long endTime = end.getTime();
        return (int) (endTime - startTime) / (60 * 60 * 1000);
    }
}