package com.souche.orbit.sun.dao;

import com.souche.optimus.common.page.Page;
import com.souche.optimus.common.vo.BaseVo;
import com.souche.optimus.dao.BasicDaoImpl;
import com.souche.optimus.dao.query.OrderParam;
import com.souche.optimus.dao.query.QueryObj;
import com.souche.optimus.dao.query.QueryParam;
import com.souche.orbit.sun.utils.StringUtils;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class BaseDaoImpl extends BasicDaoImpl implements BaseDao {

    @Autowired
    private DaoFieldApplider daoFieldApplider;

    public void setDaoFieldApplider(DaoFieldApplider daoFieldApplider) {
        this.daoFieldApplider = daoFieldApplider;
    }

    public DaoFieldApplider getDaoFieldApplider() {
        return daoFieldApplider;
    }

    @Autowired
    @Override
    public void setSqlSession(SqlSession sqlSession) {
        super.setSqlSession(sqlSession);
    }

    public SqlSession getSqlSession() {
        return super.getSession(false);
    }

    @Override
    public <E> List<E> queryListByQueryByVO(Object vo, Class<? extends E> cls) {

        QueryObj query = new QueryObj();
        query.setQuerydo(vo);
        QueryParam param = new QueryParam();
        param.andParameter(new QueryParam("deleted=#{deleted}", 0));

        query.addQueryParam(param);

        return this.findListByQuery(query, cls);
    }
    
    @Override
    public <E> List<E> queryListOrderByVO(Object vo, Class<? extends E> cls,Integer pageSize, String order_field, String order_type) {
        QueryObj query = new QueryObj();
        query.setQuerydo(vo);
        if(pageSize != null){
            query.setPageSize(pageSize);
        }
        QueryParam param = new QueryParam();
        param.andParameter(new QueryParam("deleted=#{deleted}", 0));
        if(StringUtils.isNotBlank(order_field)){
            if(StringUtils.isBlank(order_type)){
                order_type = OrderParam.ORDER_ASC;
            }
            query.addOrderParam(order_field, order_type);
        }
        

        query.addQueryParam(param);

        return this.findListByQuery(query, cls);
    }

    @Override
    public <E> Page<E> queryPageByVO(Object vo, Class<? extends E> cls, Integer currentIndex, Integer pageSize) {
        QueryObj query = new QueryObj();
        query.setPage(currentIndex);
        query.setPageSize(pageSize);
        query.setQuerydo(vo);
        QueryParam param = new QueryParam();
        param.andParameter(new QueryParam("deleted=#{deleted}", 0));
        query.addQueryParam(param);

        return queryPage(query, cls);
    }

    @Override
    public <E> Page<E> queryPageOrderByVO(Object vo, Class<? extends E> cls, Integer currentIndex,
        Integer pageSize) {
        QueryObj query = new QueryObj();
        query.setPage(currentIndex);
        query.setPageSize(pageSize);
        query.setQuerydo(vo);
        QueryParam param = new QueryParam();
        param.andParameter(new QueryParam("deleted=#{deleted}", 0));
        query.addOrderParam("date_create", OrderParam.ORDER_DESC);
        query.addQueryParam(param);

        return queryPage(query, cls);
    }

    @Override
    public <E> List<E> queryListByQueryByVOAll(Object vo, Class<? extends E> cls) {
        QueryObj query = new QueryObj();
        query.setQuerydo(vo);

        return this.findListByQuery(query, cls);
    }

    @Override
    public <E> Page<E> queryPageOrderByVO(Object vo, Class<? extends E> cls, Integer currentIndex, Integer pageSize,
        String order_field, String order_type) {
        QueryObj query = new QueryObj();
        query.setPage(currentIndex);
        query.setPageSize(pageSize);
        query.setQuerydo(vo);
        QueryParam param = new QueryParam();
        param.andParameter(new QueryParam("deleted=#{deleted}", 0));
        
        query.addOrderParam(order_field, order_type);
        
        query.addQueryParam(param);

        return queryPage(query, cls);
    }

    @Override
    public <T extends BaseVo> T saveObject(T vo) {
        daoFieldApplider.onInsert(vo);
        insert(vo);
        return vo;
    }

    @Override
    public <T extends BaseVo> T updateObject(T vo) {
        daoFieldApplider.onUpdate(vo);
        update(vo);
        return vo;
    }

    @Override
    public int countByVO(Object vo) {
        QueryObj query = new QueryObj();
        query.setQuerydo(vo);
        QueryParam param = new QueryParam();
        param.andParameter(new QueryParam("deleted=#{deleted}", 0));
        
        query.addQueryParam(param);
        
        return countByQuery(query);
    }

    
}
