package com.souche.orbit.sun.check;

import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.Arrays;
import javax.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

/**
 * @author SuperDaFu
 * @date 2018/9/6 上午10:52
 */
@Slf4j
@Aspect
@Component
public class CheckParamAspect {

    @Resource(name = "checkParamExecutor")
    private CheckParamExecutor executor;

    @Before(value = "@annotation(com.souche.orbit.sun.check.CheckParams)")
    public void checkParams(JoinPoint joinPoint) throws Throwable {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        String[] parameterNames = signature.getParameterNames();

        Method method = signature.getMethod();
        Object[] args = joinPoint.getArgs();
        Parameter[] parameters = method.getParameters();
        if (0 == args.length) {
            return;
        }
        log.debug("start check [{}]", method.getName());

        CheckParams annotation = method.getAnnotation(CheckParams.class);
        int[] indexs = annotation.indexs();
        boolean[] needCheckIndexFlag = new boolean[args.length];
        CheckParam[] paramCheckParam = new CheckParam[args.length];
        String[] paramNames = new String[args.length];

        Arrays.fill(needCheckIndexFlag, false);
        for (int index : indexs) {
            needCheckIndexFlag[index] = true;
        }
        for (int i = 0; i < parameters.length; i++) {
            Parameter parameter = parameters[i];
            CheckParam checkParamAnno = parameter.getAnnotation(CheckParam.class);
            if (checkParamAnno != null) {
                needCheckIndexFlag[i] = true;
                paramCheckParam[i] = checkParamAnno;
                paramNames[i] = parameterNames[i];
            }

        }

        for (int i = 0; i < needCheckIndexFlag.length; i++) {
            if (needCheckIndexFlag[i]) {
                if (args[i] != null) {
                    executor.checkParam(paramNames[i],args[i], paramCheckParam[i]);
                }
            }
        }
        log.debug("end check [{}]", method.getName());
    }
}
