package com.souche.orbit.sun.check;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 校验规则标识
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.PARAMETER})
public @interface CheckParam {

    /**
     * 参数格式 默认值不做格式校验
     */
    String regex() default "";

    /**
     * 枚举信息校验
     * key为枚举的 EnumToDictionary 中的key，更具BasicEnumToDictionary.getDicKey(),根据添加版本号条件进行校验
     * @since 1.5 字典服务中的key 也是支持的
     */
    String enumKey() default "";

    /**
     * 字典服务中的分组信息
     * @return
     */
    String dicGroup() default "";

    /**
     * 固定长度
     * 0以下不做校验
     */
    int length() default 0;

    String lengthRange() default "";

    /**
     * 数值范围校验
     */
    String range() default "";

    /**
     * 一般建议建议为字段描述 （比如：金额，vin码之类）
     * 错误信息抛出 errMsg + 错误类型描述 （vin码必填，vin码格式错误 等）
     */
    String errMsg() default "";

    /**
     * 是否必填信息
     */
    boolean required() default false;

    /**
     * 指定校验方法
     */
    String[] checkByModes() default {};
}
