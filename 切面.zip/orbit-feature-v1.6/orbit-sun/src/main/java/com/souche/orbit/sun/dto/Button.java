package com.souche.orbit.sun.dto;

import java.util.Objects;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Button {
    
    public Button(){}
    
    public Button(String code,String name){
        this.code = code;
        this.name = name;
    }
    
    private String code;
    
    private String name;


}
