package com.souche.orbit.sun.utils;

import com.souche.optimus.common.util.StringUtil;
import com.souche.orbit.sun.cache.MemCacheTool;
import com.souche.orbit.sun.utils.gson.GsonUtils;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;

/**
 * 索引工具类
 * @author jinrenhua
 *
 */
@Slf4j
public class SearchUtil {
    
    
    /**
     * 删除索引信息
     * @param
     * @param id
     * @param lst
     * @param obj
     * @return
     */
    public static <T> List<T> deleteSearchInfo(String searchDeleteKey,Object id,List<T> lst,T obj){
        if (StringUtil.isEmpty(MemCacheTool.get(searchDeleteKey + id))) {
            lst.add(obj);
        }else{
            log.info("deleteSearchInfo id:{}",id);
        }
        return lst;
    }

    /**
     * 更新索引信息
     * @param
     * @param id
     * @param target
     */
    public static void updateSearchInfo(String searchUpdateKey,Object id,Object target){
        String json = MemCacheTool.get(searchUpdateKey + id);
        if (log.isDebugEnabled()) {
            log.debug("updateSearchInfo: id:{},content:{}",id,json);
        }
        if(StringUtil.isNotEmpty(json)){
            Object o = GsonUtils.fromJson(json, target.getClass());
            BeanUtils.copyProperties(o, target);
        }
    }
    
    /**
     * 删除索引延迟更新的信息
     * @param
     * @param id
     */
    public static void setSearchDeleteInfo(String searchDeleteKey,Object id){
        log.debug("setSearchDeleteInfo: id:{}",id);
        MemCacheTool.set(searchDeleteKey + id, id.toString(), 10);
    }
    
    /**
     * 是否索引删除
     * @param
     * @param id
     * @return true 删除 false 未删除
     */
    public static boolean getSearchDeleteInfo(String  searchDeleteKey,Object id){
        return StringUtil.isNotEmpty(MemCacheTool.get(searchDeleteKey + id));
    }

    
    /**
     * 更新索引延迟更新的信息
     * @param
     * @param id
     */
    public static void setSearchUpdateInfo(String  searchUpdateKey,Object id,Object bean){
        String content = GsonUtils.toJson(bean);
        MemCacheTool.set(searchUpdateKey + id, content, 10);
        if (log.isDebugEnabled()) {
            log.debug("setSearchUpdateInfo:id:{},content:{}",id,content);
        }
    }
    
    /**
     * 获取更新索引延迟更新的信息
     * @param
     * @param id
     */
    public static String getSearchUpdateInfo(String searchUpdateKey,Object id){
        return MemCacheTool.get(searchUpdateKey + id);
    }
    

}
