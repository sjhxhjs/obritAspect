package com.souche.orbit.sun.check.modes;

import com.souche.orbit.sun.check.CheckMode;
import com.souche.orbit.sun.check.CheckParam;
import com.souche.orbit.sun.exception.ExceptionUtils;
import java.util.regex.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * 座机号码或手机号码
 *
 * @author SuperDaFu
 * @date 2018/9/20 下午3:55
 */
@Slf4j
public class PhoneCheckMode implements CheckMode {

    // 验证带区号的
    public static final Pattern p1 = Pattern.compile("^[0][1-9]{2,3}-[0-9]{5,10}$");
    // 验证没有区号的
    public static final Pattern p2 = Pattern.compile("^[1-9]{1}[0-9]{5,8}$");

    //手机号
    private static final Pattern patter = Pattern.compile("^([1][0-9]{10})|()$");



    @Override
    public boolean check(Object value, CheckParam checkParam) {
        String str = String.valueOf(value);
        if (StringUtils.isEmpty(str)) {
            return false;
        }
        if (str.length() > 9) {
            return p1.matcher(str).matches() || patter.matcher(str).matches();
        } else {
            return p2.matcher(str).matches();
        }
    }

    @Override
    public void error(Object value, String defaultErrorMsg) {
        throw ExceptionUtils.fail(defaultErrorMsg + "[电话校验失败]");
    }
}
