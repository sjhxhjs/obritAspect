package com.souche.orbit.sun.search;

/**
 * @author SuperDaFu
 * @date 2018/5/7 下午3:50
 */
public class SearchConstants {

    public static final class SearchType {

        /**
         * 关键字查询
         */
        public static final String KEYWORD = "KEYWORD";

        public static final String AND = "AND";
        public static final String OR = "OR";
        public static final String FILTER = "FILTER";
        public static final String FILTER_DATA_RANGE = "FILTER_DATA_RANGE";
        public static final String LIKE = "LIKE";

        /**
         * 使用 jsonarray与前端传值
         */
        public static final String ORDER = "ORDER";
        /**
         * 去重字段
         */
        public static final String DISTINCT_FIELD = "DISTINCT_FIELD";

        /**
         * 模糊查询字段
         */
        public static final String SEGEMNT = "SEGMENT";
    }
}
