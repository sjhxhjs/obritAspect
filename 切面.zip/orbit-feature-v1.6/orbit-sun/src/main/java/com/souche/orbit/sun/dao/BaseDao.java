package com.souche.orbit.sun.dao;

import com.souche.optimus.common.page.Page;
import com.souche.optimus.common.vo.BaseVo;
import com.souche.optimus.dao.BasicDao;
import java.util.List;
import org.apache.poi.ss.formula.functions.T;

public interface BaseDao extends BasicDao {
    /**
     * deleted = 0
     * @param vo
     * @param cls
     * @return
     */
    <E> List<E> queryListByQueryByVO(Object vo, Class<? extends E> cls);
    
    <E> List<E> queryListOrderByVO(Object vo, Class<? extends E> cls,Integer pageSize, String order_field, String order_type);
    /**
     * 以vo为查村条件
     * @param vo
     * @param cls
     * @return
     */
    <E> List<E> queryListByQueryByVOAll(Object vo, Class<? extends E> cls);
    
    <E> Page<E> queryPageByVO(Object vo, Class<? extends E> cls, Integer currentIndex, Integer pageSize);
    /**
     * order by date_create desc
     * @param vo
     * @param cls
     * @param currentIndex
     * @param pageSize
     * @return
     */
    <E> Page<E> queryPageOrderByVO(Object vo, Class<? extends E> cls, Integer currentIndex, Integer pageSize);

    /**
     * order by order_field,and don't care abount deleted
     * @param vo
     * @param cls
     * @param currentIndex
     * @param pageSize
     * @param order_field
     * @param order_type
     * @param <E>
     * @return
     */
    <E> Page<E> queryPageOrderByVO(Object vo, Class<? extends E> cls, Integer currentIndex, Integer pageSize,
        String order_field, String order_type);
    /**
     * count
     * @param vo
     * @return
     */
    int countByVO(Object vo);

    <T extends BaseVo>T saveObject(T vo);

    <T extends BaseVo> T updateObject(T vo);


}
