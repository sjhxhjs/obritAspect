package com.souche.orbit.sun.search.eunm;

/**
 * @author SuperDaFu
 * @date 2018/5/9 下午8:36
 */
public enum  FilterDirEnum {
    FILTER_DIR_NONE(""),
    FILTER_DIR_LESS_OR_EQUAL("<="),
    FILTER_DIR_LESS("<"),
    FILTER_DIR_GREAT_OR_EQUAL(">="),
    FILTER_DIR_GREAT(">="),
    ;

    FilterDirEnum(String code) {
        this.code = code;

    }

    private String code;

    public String getCode() {
        return code;
    }


}
