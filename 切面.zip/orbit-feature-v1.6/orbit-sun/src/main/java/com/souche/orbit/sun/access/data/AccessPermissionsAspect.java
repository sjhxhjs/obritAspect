package com.souche.orbit.sun.access.data;

import com.souche.optimus.common.page.Page;
import com.souche.orbit.sun.exception.OrbitExceptionBase;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;

/**
 * 访问权限
 *
 * @author jinrenhua
 */
@Slf4j
@Aspect
public class AccessPermissionsAspect {

    @Autowired
    private AccessPermissionsResolver accessPermissionsResolver;

    public void setAccessPermissionsResolver(AccessPermissionsResolver accessPermissionsResolver) {
        this.accessPermissionsResolver = accessPermissionsResolver;
    }

    @AfterReturning(value = "@annotation(com.souche.orbit.sun.access.data.AccessPermissions)", returning = "result")
    public void afterReturningAdvice(JoinPoint joinPoint, Object result) throws Throwable {
        if (null == result) {
            return;
        }
        if (accessPermissionsResolver == null) {
            return;
        }
        if (accessPermissionsResolver.skip()) {
            return;
        }
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();

        //如果没有用户信息则不拦截
        if (!accessPermissionsResolver.checkLogin()) {
            throw new OrbitExceptionBase("当前用户未登录，没有权限访问");
        }

        log.debug("access permissions start,method:{} beforeValue:{}", method.getName(), result);

        parseAccessPermissionsClass(result, method.getAnnotation(AccessPermissions.class));
    }

    /**
     * 访问权限校验自定义
     * 目前只实现了bean的校验 后续page or list 可以拓展
     *
     * @param accessPermissions code in（ result’s fieldName，SessionHolder map’ key）
     */
    private void parseAccessPermissionsClass(Object result, AccessPermissions accessPermissions) {
        if (result == null) {
            return;
        }
        final List<String> needCheckField = accessPermissionsResolver.getNeedCheckField();
        final String[] value = accessPermissions.value();
        if (value != null && value.length != 0) {
            for (String s : value) {
                needCheckField.add(s);
            }
        }
        Map<String, Object> param = new HashMap<>(needCheckField.size());

        if (result instanceof List<?>) {
            List<?> list = (List<?>) result;
            if (!CollectionUtils.isEmpty(list)) {
                for (Object o : list) {
                    Map<String, Object> maps = injectValue(o, needCheckField);
                    accessPermissionsResolver.checkAccessPermissions(maps);
                }
            }
        } else if (result instanceof Page<?>) {
            Page<?> page = (Page<?>) result;
            if (page != null) {
                final List<?> items = ((Page<?>) result).getItems();
                if (!CollectionUtils.isEmpty(items)) {
                    for (Object o : items) {
                        Map<String, Object> maps = injectValue(o, needCheckField);
                        accessPermissionsResolver.checkAccessPermissions(maps);
                    }
                }
            }
        } else {
            Map<String, Object> maps = injectValue(result, needCheckField);
            accessPermissionsResolver.checkAccessPermissions(maps);
        }
    }


    /**
     * inject key to value on result
     *
     * @param keys get fieldName
     */
    private Map<String, Object> injectValue(Object result, List<String> keys) {

        if (result == null) {
            return null;
        }
        Map<String, Object> valueMap = new HashMap<>();
        Class<? extends Object> cls = result.getClass();

        while (cls.getSuperclass() != null) {
            Field[] fields = cls.getDeclaredFields();

            for (Field field : fields) {
                if (Modifier.isStatic(field.getModifiers())) {
                    continue;
                }
                String fieldName = field.getName();
                if (keys.contains(fieldName)) {
                    field.setAccessible(true);

                    try {
                        final Object o = field.get(result);
                        valueMap.put(fieldName, o);
                    } catch (Exception e) {
                        log.error("AccessPermissionsAspect inject error! 获取结果信息失败", e);
                    }
                }
            }
            cls = cls.getSuperclass();
        }
        return valueMap;
    }
}
