package com.souche.orbit.sun.access.data;

/**
 * @author SuperDaFu
 * @date 2019/2/20 下午3:44
 */
public @interface AccessPermissions {

    /**
     * 业务方除了设置了默认校验字段，当存在临时字段，字段改字段，一般情况不需要设定
     * @return
     */
    String[] value() default "";
}
