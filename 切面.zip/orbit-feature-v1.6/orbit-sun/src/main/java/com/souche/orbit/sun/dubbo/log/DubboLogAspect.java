package com.souche.orbit.sun.dubbo.log;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

/**
 * @author SuperDaFu
 * @date 2018/4/23 下午3:41
 */
@Component("dubboLogAspect")
@Aspect
@Slf4j
public class DubboLogAspect {


    @Around("@within(com.souche.orbit.sun.dubbo.log.DubboLog)")
    public Object printSPILogger(ProceedingJoinPoint joinPoint) throws Throwable {
        try {
            log.info("DUBBO:" + joinPoint.getSignature() + " params:" + printArgs(joinPoint.getArgs()));
            Object proceed = joinPoint.proceed();
            log.info("DUBBO-RESULT:" + JSONObject.toJSONString(proceed));
            return proceed;
        } catch (Throwable throwable) {
            log.error(
                joinPoint.getSignature().getName() + "throws Exception \n" + " params:" + printArgs(joinPoint.getArgs())
                    + "\n", throwable);
            if (joinPoint.getTarget() instanceof Pair) {
                return Pair.of(null, throwable);
            } else {
                throw throwable;
            }
        }
    }

    private String printArgs(Object[] args) {
        String s = JSONObject.toJSONString(args, SerializerFeature.PrettyFormat);
        return s;
    }
}
