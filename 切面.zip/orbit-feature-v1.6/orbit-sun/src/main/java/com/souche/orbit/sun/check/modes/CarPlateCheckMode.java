package com.souche.orbit.sun.check.modes;

import com.souche.orbit.sun.check.CheckMode;
import com.souche.orbit.sun.check.CheckParam;
import com.souche.orbit.sun.exception.ExceptionUtils;
import java.util.regex.Pattern;
import org.apache.commons.lang3.StringUtils;

/**
 * @author SuperDaFu
 * @date 2018/9/20 下午3:49
 */

public class CarPlateCheckMode implements CheckMode {

    public static final Pattern pattern = Pattern
        .compile("^[京津沪渝蒙新藏宁桂港澳黑吉辽晋冀青鲁豫苏皖浙闽赣湘鄂粤琼甘陕黔滇川]{1}[A-Z]{1}[A-Z0-9]{4,6}$");

    @Override
    public boolean check(Object value, CheckParam checkParam) {
        String str = value == null ? "" : String.valueOf(value);
        if (StringUtils.isNotEmpty(String.valueOf(str))) {
            return pattern.matcher(str).matches();
        }
        return true;
    }

    @Override
    public void error(Object value, String defaultErrorMsg) {
        throw ExceptionUtils.fail(defaultErrorMsg + "[车牌校验失败]");
    }

}
