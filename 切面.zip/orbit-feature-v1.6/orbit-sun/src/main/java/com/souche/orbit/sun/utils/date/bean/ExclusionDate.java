package com.souche.orbit.sun.utils.date.bean;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ExclusionDate {
    /**
     * 见ExclusionDateTypeEnum枚举
     */
    private String type;
    /**
     * type = 1-6,HH:mm:ss
     * type = 8 ,时间戳
     * type = 9 ,yyyy-MM-dd HH:mm:ss
     */
    private String start;
    /**
     * type = 1-6,HH:mm:ss
     * type = 8 ,时间戳
     * type = 9 ,yyyy-MM-dd HH:mm:ss
     */
    private String end;
    
    
    public enum ExclusionDateTypeEnum{
        SUNDAY("0","周日"),
        MONDAY("1","周一"),
        TUESDAY("2","周二"),
        WEDNESDAY("3","周三"),
        THURSDAY("4","周四"),
        FRIDAY("5","周五"),
        SATURDAY("6","周六"),
        TIME_IN_MILLIS("8","时间戳"),
        TIME("9","时分秒时间（yyyy-MM-dd HH:mm:ss）"),
        ;
        
        
        private String code;
        private String displayName;

        ExclusionDateTypeEnum(String code, String displayName) {
            this.code = code;
            this.displayName = displayName;
        }

        public String getCode() {
            return code;
        }

        public String getDisplayName() {
            return displayName;
        }
        
    }

}
