package com.souche.orbit.sun.access.data;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author SuperDaFu
 * @date 2019/2/20 下午4:43
 */
@Slf4j
@Aspect
public class AccessPermissionsDaoAspect {

    @Autowired
    private AccessPermissionsAspect accessPermissionsAspect;
    @Value("${access.permission.dao}")
    private boolean accessDao = true;


    @AfterReturning(value = "execution(* com.souche.orbit.sun.dao.BaseDaoImpl+.*(..))", returning = "result")
    public void afterReturningAdvice(JoinPoint joinPoint, Object result) throws Throwable {
        if (accessDao) {
            accessPermissionsAspect.afterReturningAdvice(joinPoint, result);
        }
    }
}
