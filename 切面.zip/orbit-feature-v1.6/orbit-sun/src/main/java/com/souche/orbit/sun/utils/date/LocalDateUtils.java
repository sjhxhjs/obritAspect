package com.souche.orbit.sun.utils.date;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.temporal.TemporalAdjusters;
import java.util.Date;
import org.springframework.util.Assert;

/**
 * @author SuperDaFu
 * @date 2018/11/19 下午6:04
 */
public class LocalDateUtils {

    public static LocalDate fromDate(Date date) {
        if (date == null) {
            return null;
        }
        if (date instanceof java.sql.Date) {
            date = new Date(date.getTime());
        }
        return date.toInstant().atZone(ZoneOffset.systemDefault()).toLocalDate();
    }

    public static Date toDate(LocalDate localDate) {
        ZoneId zone = ZoneId.systemDefault();
        Instant instant = localDate.atStartOfDay().atZone(zone).toInstant();
        return Date.from(instant);
    }
    /**
     * 获取下个月1日
     * @param date
     * @return
     */
    public static LocalDate nextMonthStartDay(LocalDate date) {
        final LocalDate localDate = date.plusMonths(1);
        return LocalDate.of(localDate.getYear(), localDate.getMonth(), 1);
    }
    /**
     * 检查两个时间 是否 是同一个月份
     * @param date1
     * @param date2
     * @return
     */
    public static boolean checkInSameMonth(LocalDate date1, LocalDate date2) {
        return date1.getYear() == date2.getYear() && date1.getMonth() == date2.getMonth();
    }

    /**
     * 获取月末时间
     * @param date
     * @return
     */
    public static LocalDate getMonthEndDay(LocalDate date){
        return date.with(TemporalAdjusters.lastDayOfMonth());
    }

    public static int between(LocalDate a, LocalDate bn) {
        Assert.notNull(a);
        Assert.notNull(bn);
        return (int) (Math.abs(a.toEpochDay() - bn.toEpochDay()) + 1);
    }

    public static int nowSecond(){
        return Math.toIntExact(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")));
    }
}
