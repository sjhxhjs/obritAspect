package com.souche.orbit.sun.eunm;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.souche.optimus.common.config.OptimusConfig;
import com.souche.optimus.common.util.StringUtil;
import com.souche.orbit.sun.dto.FilterDTO;
import com.souche.orbit.sun.eunm.feature.EnumChangeName;
import com.souche.orbit.sun.eunm.feature.EnumSort;
import com.souche.orbit.sun.eunm.feature.EnumVersion;
import com.souche.orbit.sun.utils.ClassLoaderUtil;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import lombok.extern.slf4j.Slf4j;

/**
 * 枚举转换字典
 *
 * @author jinrenhua
 */
@Slf4j
public class BasicEnumToDictionary {


    public static Map<String, Map<String, String>> basicDic = new ConcurrentHashMap<String, Map<String, String>>();

    static {

        //过多个包名，用','分割
        String packageName = OptimusConfig.getValue("package_name", "com.souche");

        log.info("get class for enum packageName : " + packageName);

        String[] packageNames = packageName.split(",");

        for (String package_name : packageNames) {
            final List<Class> aClass = ClassLoaderUtil.getClass(package_name);
            for (Class cls : aClass) {
                log.info("加载到class：" + cls.getName());
                if (cls != null) {
                    putBasicDicInfo(cls);
                }

            }
        }
    }

    /**
     * 加载每个枚举对象数据
     */
    private static void putBasicDicInfo(Class<?> cls) {
        try {

            EnumToDictionary enumToDic = cls.getAnnotation(EnumToDictionary.class);
            if (enumToDic == null) {
                log.info("not find EnumToDictionary for class : " + cls.getName());
                return;
            }

            String key = "";
            if (enumToDic != null) {
                key = enumToDic.key();
            }
            if (StringUtil.isEmpty(key) || key.contains(".")) {
                log.info("EnumToDictionary 缺少key或可能key中包含'.',class:[{}]", cls.getName());
                return;
            }
            if (!StringUtil.isEmpty(key)) {
                Map<String, Map<String, String>> enumMaps = putMap(cls, key);
                basicDic.putAll(enumMaps);
            }
        } catch (Exception e) {
            log.error("putBasicDicInfo error!", e);
        }

    }

    private static Map<String, Map<String, String>> putMap(Class cls, String baseKey) {
        try {
            log.info("bassDic enum parse class [{}]", cls.getName());

            //数据准备，准备该类的枚举类
            Method method = cls.getMethod("values");
            EnumMessage inter[] = (EnumMessage[]) method.invoke(null, null);

            List<EnumMessage> enums = Lists.newLinkedList();
            List<Class> interfaces = new ArrayList<>();
            Class clz = cls;
            do {
                Class[] inters = clz.getInterfaces();
                for (Class aClass : inters) {
                    interfaces.add(aClass);
                }
                clz = clz.getSuperclass();
            } while (clz != null);

            boolean haveVersion = false;
            boolean haveChangeName = false;
            boolean haveSort = false;
            for (Class anInterface : interfaces) {
                if (anInterface.equals(EnumVersion.class)) {
                    haveVersion = true;
                } else if (anInterface.equals(EnumChangeName.class)) {
                    haveChangeName = true;
                    haveVersion = true;
                } else if (anInterface.equals(EnumSort.class)) {
                    haveSort = true;
                    haveVersion = true;
                }
            }
            int maxVersion = 0;
            //版本号集合
            for (EnumMessage enumMessage : inter) {
                if (haveVersion) {
                    EnumVersion enumVersion = (EnumVersion) enumMessage;
                    Integer version = enumVersion.getVersion();
                    if (version != null && maxVersion < version) {
                        maxVersion = version;
                    }
                }
                enums.add(enumMessage);
            }

            Map<String, Map<String, String>> dicMaps = Maps.newLinkedHashMap();

            //写入默认的 枚举值
            String defaultKey = getDicKey(baseKey, 0);
            dicMaps.put(defaultKey, mapEnums(enums));
            //写入个版本枚举集合包含改名功能或者排序
            List<EnumSet> translationEnum = translationEnum(enums, haveVersion, haveChangeName, haveSort);
            if (haveVersion) {

                int versionCount = Integer.toBinaryString(maxVersion).length() + 1;
                int version = 0;

                for (int i = 0; i < versionCount; i++) {
                    String dicKey = getDicKey(baseKey, version);
                    List<EnumSet> allowEnums = new ArrayList<>();
                    for (EnumSet anEnum : translationEnum) {

                        if (version == 0 || anEnum.enumVersion.getVersion() == null
                            || (anEnum.enumVersion.getVersion() & version) != 0) {
                            allowEnums.add(anEnum);
                        }
                    }
                    if (haveSort) {
                        allowEnums.sort((o1, o2) -> o1.enumSort.compare(o2.enumSort));
                    }
                    Map<String, String> soredMap = Maps.newLinkedHashMap();
                    for (EnumSet allowEnum : allowEnums) {
                        if (haveChangeName) {
                            soredMap
                                .put(allowEnum.enumMessage.getCode(), allowEnum.enumChangeName.getChangeName(version));
                        } else {
                            soredMap.put(allowEnum.enumMessage.getCode(), allowEnum.enumMessage.getDisplayName());
                        }
                    }
                    dicMaps.put(dicKey, soredMap);
                    if (version == 0) {
                        version = 1;
                    } else {
                        version *= 2;
                    }
                }
            }
            log.info("putMap maps:{}", dicMaps);
            return dicMaps;
        } catch (Exception e) {
            log.error("putMap error", e);
            return null;
        }
    }

    private static List<EnumSet> translationEnum(List<EnumMessage> enums, boolean haveVersion, boolean haveChangeName,
        boolean haveSort) {
        List<EnumSet> resultSet = new ArrayList<>();

        for (EnumMessage anEnum : enums) {
            EnumSet setItem = new EnumSet();
            setItem.enumMessage = anEnum;
            if (haveVersion) {
                setItem.enumVersion = (EnumVersion) anEnum;
            }
            if (haveChangeName) {
                setItem.enumChangeName = (EnumChangeName) anEnum;
            }
            if (haveSort) {
                setItem.enumSort = (EnumSort) anEnum;
            }
            resultSet.add(setItem);
        }
        return resultSet;
    }

    private static Map<String, String> mapEnums(List<EnumMessage> enums) {
        Map<String, String> dicMap = new LinkedHashMap<>();

        for (EnumMessage anEnum : enums) {
            dicMap.put(anEnum.getCode(), anEnum.getDisplayName());
        }
        return dicMap;
    }

    public static String getDicKey(String baseKey, Integer versionCode) {
        if (versionCode == null || 0 == versionCode) {
            return baseKey;
        }
        return baseKey + "." + versionCode;
    }

    public static class EnumSet {

        EnumMessage enumMessage;
        EnumVersion enumVersion;
        EnumChangeName enumChangeName;
        EnumSort enumSort;
    }

    public static FilterDTO translationMapToList(String key, String name, String paramKey) {
        FilterDTO filterDTO = new FilterDTO();
        filterDTO.setKey(paramKey);
        filterDTO.setName(name);
        List<FilterDTO> result = new ArrayList<>();
        Map<String, String> map = BasicEnumToDictionary.basicDic.get(key);
        Iterator<Entry<String, String>> iterator = map.entrySet().iterator();
        while (iterator.hasNext()) {
            Entry<String, String> next = iterator.next();
            FilterDTO i = new FilterDTO();
            i.setName(next.getValue());
            i.setKey(next.getKey());
            result.add(i);
        }
        filterDTO.setContent(result);
        return filterDTO;
    }
}