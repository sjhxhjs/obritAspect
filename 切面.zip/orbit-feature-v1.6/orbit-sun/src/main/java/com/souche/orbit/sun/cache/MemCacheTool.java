package com.souche.orbit.sun.cache;

import com.alibaba.fastjson.JSONObject;
import com.souche.optimus.cache.Memcached;
import com.souche.optimus.common.config.OptimusConfig;
import com.souche.optimus.common.util.MD5Utils;
import com.souche.orbit.sun.utils.gson.GsonUtils;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Memcahce 工具类， 写入去除缓存
 */
@Slf4j
public class MemCacheTool {
    private static final Logger LOGGER = LoggerFactory.getLogger(MemCacheTool.class);
    private static String PREFIX_GENERALIZE = OptimusConfig.getValue("memcached.prefix");
    private static Memcached memcached;

    static {
        memcached = new Memcached();
        try {
            memcached.init();
        } catch (Exception e) {
            LOGGER.error("缓存客户端创建失败，请检查缓存服务是否正常", e);
        }
    }


    public static Map<String, String> getAllByList(List<String> md5List) {
        Map<String, String> map = new HashMap<String, String>();
        for (String md5 : md5List) {
            String content = get(md5);
            if (content == null) {
                continue;
            }
            map.put(md5, content);
        }
        return map;
    }

    public static String get(String md5) {
        try {
            String content = memcached.get(PREFIX_GENERALIZE + md5);
            if (StringUtils.isEmpty(content)) {
                return null;
            } else {
                return content;
            }
        } catch (Exception e) {
            LOGGER.error("memcached get error", e);
        }
        return "";
    }


    public static void set(String md5, String content, int expiredTime) {
        try {
            String oldContent = get(md5);
            if (StringUtils.isEmpty(oldContent)) {
                memcached.add(PREFIX_GENERALIZE + md5, content, expiredTime);
            } else {
                memcached.set(PREFIX_GENERALIZE + md5, content);
            }

        } catch (Exception e) {
            LOGGER.error("memcached set error", e);
        }
    }

    public static String getByName(String name) {
        try {
            String content = memcached.get(name);
            if (StringUtils.isEmpty(content)) {
                return null;
            } else {
                return content;
            }
        } catch (Exception e) {
            LOGGER.error("memcached getByName error", e);
        }
        return "";
    }


    public static void del(String name) {
        try {
            memcached.del(name);
        } catch (Exception e) {
            LOGGER.error("memcached del error", e);
        }
    }

    public static void remove(String md5) {
        try {
            memcached.del(PREFIX_GENERALIZE + md5);

        } catch (Exception e) {
            LOGGER.error("memcached remove error", e);
        }
    }

    public static List<String> getObjectList(String key) {
        return getObjectList(key, String.class);
    }

    public static <T> List<T> getObjectList(String key, Class<T> clazz) {
        try {
            if (StringUtils.isEmpty(key) || clazz == null) {
                return null;
            }
            String jsonValue = get(key);
            return StringUtils.isEmpty(jsonValue) ? null : JSONObject.parseArray(jsonValue, clazz);
        } catch (Exception e) {
            LOGGER.error("memcached getObjectList error", e);
            return null;
        }
    }

    public static <T> T getObject(String key, Class<T> clazz) {
        try {
            if (StringUtils.isEmpty(key) || clazz == null) {
                return null;
            }
            String jsonValue = get(key);
            return StringUtils.isEmpty(jsonValue) ? null : JSONObject.parseObject(jsonValue,clazz);
        } catch (Exception e) {
            LOGGER.error("memcached getObject error", e);
            return null;
        }
    }

    public static void setObject(String key, Object value, int exprieSecond) {
        if (StringUtils.isEmpty(key) || value == null || exprieSecond < 0) {
            return;
        }
        set(key, GsonUtils.toJsonString(value), exprieSecond);
    }



    /**
     * get cache key
     *
     * @param prefix
     * @param group
     * @param param
     * @return
     */
    public static String getCacheKey(String prefix, String group, Object... param) {
        StringBuilder sb = new StringBuilder(prefix);

        if (param != null) {
            for (Object obj : param) {
                if (obj != null)
                {
                    sb.append(String.valueOf(obj));
                }

            }
        }
        sb.append(group);
        log.debug("cache key:"+sb.toString());
        return MD5Utils.md5(sb.toString());
    }
}
