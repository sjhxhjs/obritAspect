package com.souche.orbit.sun.check;

import com.google.common.collect.Maps;
import com.souche.orbit.sun.exception.ExceptionUtils;
import com.souche.orbit.sun.exception.OrbitExceptionBase;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * @author SuperDaFu
 * @date 2018/9/20 下午3:28
 */
@Slf4j
public class CheckModeRegister {

    private Map<String,CheckMode> checkModeMaps = Maps.newConcurrentMap();

    /**
     * 添加 校验模式
     * @param key
     * @param checkMode
     */
    public synchronized void addCheckMode(String key, CheckMode checkMode) {
        if (StringUtils.isEmpty(key)) {
            throw new OrbitExceptionBase("添加校验模式失败，key为空");
        }
        if (checkMode == null) {
            throw ExceptionUtils.fail("添加校验模式失败, checkMode为空");
        }
        CheckMode oldCheck = checkModeMaps.get(key);
        if (oldCheck != null) {
            log.warn("CheckMode rewrite key:{}", key);
        }
        checkModeMaps.put(key, checkMode);
        log.info("addCheckMode key:{}", key);
    }

    /**
     * 获取校验模式
     * @param key
     * @return
     */
    public CheckMode getCheckMode(String key) {
        return checkModeMaps.get(key);
    }

}
