package com.souche.orbit.sun.json.param;

import lombok.Data;

/**
 * @author SuperDaFu
 * @date 2019/4/10 上午9:46
 */
@Data
public class DicParam {

    private String code;
    private Integer version;
}
