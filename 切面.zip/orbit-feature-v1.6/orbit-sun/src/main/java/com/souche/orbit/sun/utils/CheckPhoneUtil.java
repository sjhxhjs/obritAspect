package com.souche.orbit.sun.utils;

import com.souche.optimus.common.util.StringUtil;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author honglei
 * @date 2018/11/13 下午2:19
 */
public class CheckPhoneUtil {

    private static final Pattern mobilePattern = Pattern.compile("^([1][0-9]{10})|()$");

    private static final Pattern telPhonePattern = Pattern.compile("^[0][1-9]{2,3}-[0-9]{5,10}$");
    private static final Pattern telPhonePatternWithOut = Pattern.compile("^[1-9]{1}[0-9]{5,8}$");

    /**
     * 手机号验证
     *
     * @return 验证通过返回true
     */
    public static boolean isMobile(String str) {
        if (StringUtil.isEmpty(str)) {
            return false;
        }
        Matcher m = mobilePattern.matcher(str);
        return m.matches();
    }

    public static boolean isNotMobile(String str) {
        return !isMobile(str);
    }

    /**
     * 电话号码验证
     *
     * @return 验证通过返回true
     */
    public static boolean isPhone(String str) {
        if (StringUtil.isEmpty(str)) {
            return false;
        }
        Matcher m = null;
        boolean b = false;
        if (str.length() > 9) {
            m = telPhonePattern.matcher(str);
            b = m.matches();
        } else {
            m = telPhonePatternWithOut.matcher(str);
            b = m.matches();
        }
        return b;
    }
}
