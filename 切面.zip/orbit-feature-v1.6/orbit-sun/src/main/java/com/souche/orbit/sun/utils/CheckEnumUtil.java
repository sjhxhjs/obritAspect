package com.souche.orbit.sun.utils;


import com.souche.orbit.sun.eunm.BasicEnumToDictionary;
import com.souche.orbit.sun.utils.StringUtils;

/**
 * 枚举校验类
 * @author jinrenhua
 * @date 2018年12月12日 上午11:06:15
 */
public class CheckEnumUtil {
    
    /**
     * 枚举是否有值
     * @param code 枚举basicDic的code
     * @param key 具体枚举的key
     * @return false : 没有值
     */
    public static boolean hasValue(String code,String key){
        return hasValue(code, 0, key);
    }
    
    /**
     * 枚举是否值
     * @param code 枚举basicDic的code
     * @param version 枚举版本号
     * @param key 具体枚举的key
     * @return false : 没有值
     */
    public static boolean hasValue(String code,Integer version,String key){
        
        if(StringUtils.isEmpty(code) || StringUtils.isEmpty(key)){
            return false;
        }
        
        if(BasicEnumToDictionary.basicDic.get(BasicEnumToDictionary.getDicKey(code, version)) != null
                && StringUtils.isNotEmpty(BasicEnumToDictionary.basicDic.get(BasicEnumToDictionary.getDicKey(code, version)).get(key))){
            return true;
        }
        return false;
    }
    
}
