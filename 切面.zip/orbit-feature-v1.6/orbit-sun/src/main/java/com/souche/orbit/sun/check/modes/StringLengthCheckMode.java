package com.souche.orbit.sun.check.modes;


import com.souche.orbit.sun.check.CheckMode;
import com.souche.orbit.sun.check.CheckParam;
import com.souche.orbit.sun.exception.ExceptionUtils;

/**
 * @author SuperDaFu
 * @date 2018/9/21 上午10:38
 */
public class StringLengthCheckMode implements CheckMode {

    @Override
    public boolean check(Object value, CheckParam checkParam) {
        String vStr = String.valueOf(value);
        if (checkParam.length() != vStr.length()) {
            return false;
        }
        return true;
    }

    @Override
    public void error(Object value, String defaultErrorMsg) {
        throw ExceptionUtils.fail(defaultErrorMsg+"[文本长度超出限制]");
    }

}
