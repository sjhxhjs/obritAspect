package com.souche.orbit.sun.cache;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface CacheClear {

    /**
     * Cache group of current result will be stored.
     * 
     * @return String cache group name
     */
    String group() default "default";

    /**
     * The prefix of cache key.
     * 
     * @return String
     */
    String prefix();

    /**
     * object for cache in index.
     * 
     * @return int
     */
    int clearIndex() default 0;

    /**
     * clear cache keys
     * <p>
     * Each value represents a key combination, combination key separator is ","
     * 
     * @return Combination of key collection
     */
    String[] clearKeys() default {"id"};

}
