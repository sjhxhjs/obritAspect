package com.souche.orbit.sun.exception;

import com.souche.optimus.exception.OptimusExceptionBase;

/**
 * @author SuperDaFu
 * @date 2018/9/6 上午11:03
 */
public class OrbitExceptionBase extends OptimusExceptionBase {
    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public OrbitExceptionBase(){
        super();
    }

    public OrbitExceptionBase(String message){
        super(message);
    }

    public OrbitExceptionBase(String message, Throwable cause){
        super(message, cause);
    }

    public OrbitExceptionBase(Throwable cause){
        this(cause.getMessage(), cause);
    }

    public String getErrorMessage(){
        return "系统内部异常";
    }
}
