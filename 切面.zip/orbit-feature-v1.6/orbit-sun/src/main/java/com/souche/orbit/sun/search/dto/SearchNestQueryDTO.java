package com.souche.orbit.sun.search.dto;

import java.util.List;
import lombok.Data;

/**
 * @author SuperDaFu
 * @date 2019/5/14 上午11:20
 */
@Data
public class SearchNestQueryDTO {

    /**
     * 外键字段
     */
    private String path;

    /**
     * 需要满足的条件         aaa="aaa"
     */
    private List<String> andQuery;
}
