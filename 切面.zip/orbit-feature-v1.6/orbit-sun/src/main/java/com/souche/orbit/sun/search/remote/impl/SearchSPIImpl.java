package com.souche.orbit.sun.search.remote.impl;

import com.alibaba.fastjson.JSONObject;
import com.souche.elastic.search.api.SearchService;
import com.souche.elastic.search.common.ESSearchResponse;
import com.souche.elastic.search.common.SearchQuery;
import com.souche.orbit.sun.search.dto.SearchQueryDTO;
import com.souche.orbit.sun.search.dto.SearchResponseDTO;
import com.souche.orbit.sun.search.remote.SearchSPI;
import javax.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.stereotype.Service;

/**
 * @author SuperDaFu
 * @date 2018/5/2 上午10:39
 */
@Service("searchSPI")
@Slf4j
public class SearchSPIImpl implements SearchSPI {

    @Resource(name = "searchService")
    private SearchService searchService;

    @Override
    public Pair<SearchResponseDTO, Throwable> query(SearchQueryDTO query) {
        final SearchQuery searchQuery = query.createSearchQuery();
        log.info("SEARCHQUERY:{}", JSONObject.toJSONString(searchQuery));
        return doSearch(searchQuery);
    }

    @Override
    public Pair<SearchResponseDTO, Throwable> query(SearchQuery searchQuery) {
        log.info("SEARCHQUERY:{}", JSONObject.toJSONString(searchQuery));
        return doSearch(searchQuery);
    }

    private Pair<SearchResponseDTO, Throwable> doSearch(SearchQuery searchQuery) {
        ESSearchResponse response = null;
        try {
            response = searchService.ngQuery(searchQuery);
            log.info("SEARCHQUERY_RESULT:{}", JSONObject.toJSONString(response));
            return Pair.of(new SearchResponseDTO(response), null);
        } catch (Exception e) {
            log.error("搜索发生异常", e);
            return Pair.of(null, e);
        }
    }
}
