package com.souche.orbit.sun.check;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 标记需要进行参数校验
 * @author SuperDaFu
 * @date 2018/9/6 上午10:47
 */
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface CheckParams {
    /**
     * 需要检验的参数位置
     * 默认是第一个 0 允许多个
     * @return
     */
    int[] indexs() default {0};

}
