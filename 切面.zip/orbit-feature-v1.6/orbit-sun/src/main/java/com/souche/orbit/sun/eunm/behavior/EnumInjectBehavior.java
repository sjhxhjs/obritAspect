package com.souche.orbit.sun.eunm.behavior;


import com.souche.orbit.sun.eunm.EnumValue;

/**
 * 相关信息注入，自定义注入行为
 * @author SuperDaFu
 * @date 2018/5/16 上午11:20
 */
public interface EnumInjectBehavior {

     /**
      * 或者枚举值
      * @param enumValue 字段注解
      * @param relateValue relate关联的值
      * @return
      */
     String getValue(EnumValue enumValue, Object relateValue);
}
