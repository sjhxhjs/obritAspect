package com.souche.orbit.sun.check;

/**
 * @author SuperDaFu
 * @date 2018/9/20 下午3:29
 */
public interface CheckMode {

    /**
     * 校验动作
     * @param value 被校验的值
     */
    boolean check(Object value, CheckParam checkParam);

    void error(Object value, String defaultErrorMsg);
}
