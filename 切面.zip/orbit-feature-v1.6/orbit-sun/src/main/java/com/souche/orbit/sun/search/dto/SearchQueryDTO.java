package com.souche.orbit.sun.search.dto;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.souche.elastic.search.common.Aggregate;
import com.souche.elastic.search.common.SearchQuery;
import com.souche.optimus.common.util.CollectionUtils;
import com.souche.optimus.common.util.StringUtil;
import com.souche.orbit.sun.OrbitSunConstant;
import com.souche.orbit.sun.search.SearchConstants.SearchType;
import com.souche.orbit.sun.search.annotation.SearchParam;
import com.souche.orbit.sun.search.eunm.FilterDirEnum;
import com.souche.orbit.sun.utils.ReflectionUtils;
import com.souche.orbit.sun.utils.SortMappingUtils;
import com.souche.orbit.sun.utils.StringUtils;
import com.souche.orbit.sun.utils.date.DateUtils;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 聚合操作不支持
 *
 * @author SuperDaFu
 * @date 2018/5/2 上午10:55
 */
@Data
@Slf4j
public class SearchQueryDTO<T> implements Serializable {

    private static final Logger LOGGER = LoggerFactory.getLogger(SearchQueryDTO.class);

    public static final String SEARCH_SRC = OrbitSunConstant.SEARCH_SRC_NAME;

    public static final Map<String, Map<String, String>> PO_FIELD_COLUMN = Maps.newConcurrentMap();
    /**
     * 用来设置and的Vo
     */
    private T paramVo;

    private String indexName;
    private Integer currentIndex;
    private Integer pageSize;

    private String keyword;
    /**
     * 去重的字段
     */
    private String distinctField;

    private Map<String, String> andMap;
    private Map<String, List<String>> orMap;
    private Map<String, String> sortMap;
    /**
     * 需要进行模糊查询的字段
     */
    private Map<String, String> segmentMap;
    private List<SearchNestQueryDTO> nestQueryList;
    /**
     * 需要抓取的字段
     */
    private String fetchFields;


    private List<String> filterList;

    private List<Aggregate> aggregate;
    /**
     * 相对复杂的查询
     */
    private String querys = "";

    public SearchQueryDTO() {
        orMap = Maps.newLinkedHashMap();
        andMap = Maps.newLinkedHashMap();
        sortMap = Maps.newLinkedHashMap();
        aggregate = Lists.newLinkedList();
        filterList = Lists.newLinkedList();
        segmentMap = Maps.newLinkedHashMap();
        nestQueryList = Lists.newLinkedList();
    }

    public SearchQueryDTO(T vo) {
        this();
        paramVo = vo;
    }

    public SearchQuery createSearchQuery() {
        SearchQuery searchQuery = new SearchQuery();

        if (paramVo != null) {
            //todo dubbo调用会变成hashmap 要处理掉
            if (paramVo instanceof HashMap) {

            } else {
                Class<?> aClass = paramVo.getClass();
                Field[] declaredFields = aClass.getDeclaredFields();
                for (int i = 0; i < declaredFields.length; i++) {
                    Field field = declaredFields[i];
                    SearchParam annotation = field.getAnnotation(SearchParam.class);
                    String columnName = getColumnName(aClass, declaredFields[i]);
                    if (annotation != null) {
                        if (!annotation.ignore()) {
                            parseSearchParam(field, annotation, columnName);
                        }
                    } else {
                        //默认动作   当做And 条件进行处理
                        addToMap(field, paramVo, columnName, andMap);
                    }
                }
            }
        }
        if (CollectionUtils.isNotEmpty(nestQueryList)) {
            Map<String,String> map = new HashMap<>();
            for (SearchNestQueryDTO searchNestQueryDTO : nestQueryList) {
                final List<String> andQuery = searchNestQueryDTO.getAndQuery();
                if (CollectionUtils.isNotEmpty(andQuery)) {
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < andQuery.size(); i++) {
                        sb.append(andQuery.get(i));
                        if (i != andQuery.size() - 1) {
                            sb.append(" AND ");
                        }
                    }
                        map.put(searchNestQueryDTO.getPath(), sb.toString());
                }
            }
            if (CollectionUtils.isNotEmpty(map)) {
                searchQuery.setNestedQuery(map);
            }
        }
        if (!andMap.isEmpty()) {
            searchQuery.setAndQuerys(andMap);
        }
        if (!orMap.isEmpty()) {
            searchQuery.setOrQuerys(orMap);
        }
        if (!aggregate.isEmpty()) {
            searchQuery.setAggregate(aggregate);
        }
        if (StringUtil.isNotEmpty(keyword)) {
            searchQuery.setKey_word(keyword);
        }
        if (sortMap.isEmpty()) {
            sortMap.put("date_create", "desc");
        }
        searchQuery.setSort(sortMap);

        if (!StringUtils.isEmpty(distinctField)) {
            searchQuery.setDistinctField(distinctField);
        }
        if (!filterList.isEmpty()) {
            searchQuery.setFilters(filterList);
        }
        if (StringUtils.isNotEmpty(querys)) {
            searchQuery.setQuerys(querys);
        }
        if (!segmentMap.isEmpty()) {
            searchQuery.setSegmentFields(segmentMap);
        }
        if (StringUtils.isNotBlank(fetchFields)) {
            searchQuery.setFetchFields(fetchFields);
        }
        //设置indexName
        searchQuery.setSrc(SEARCH_SRC);
        if (StringUtils.isEmpty(indexName)) {
            throw new IllegalArgumentException("indexName 不能为空");
        }
        searchQuery.setIndexName(indexName);
        //设置分页信息
        if (pageSize != null) {
            searchQuery.setSize(pageSize);

            if (currentIndex != null) {
                int offset = (currentIndex - 1 < 0 ? 0 : currentIndex - 1) * pageSize;
                searchQuery.setStart(offset);
            }
        } else {
            searchQuery.setSize(100);
            searchQuery.setStart(0);
        }

        log.info("索引查询条件：" + JSONObject.toJSON(searchQuery));

        return searchQuery;
    }

    private void parseSearchParam(Field field, SearchParam annotation, String columnName) {
        switch (annotation.type()) {
            case SearchType.AND:
                addToMap(field, paramVo, columnName, andMap);
                break;
            case SearchType.KEYWORD:
                if (StringUtils.isEmpty(keyword)) {
                    String tKeyword = getFieldStringValue(field, paramVo);
                    if (tKeyword != null) {
                        tKeyword = tKeyword.trim();
                    }
                    //keyword 不指定label 同时columnName = keyword 这直接使用关键字查询，否则使用or 进行处理
                    if (StringUtils.isNotEmpty(columnName) && !"keyword".equals(columnName)) {
                        String[] split = columnName.split(",");
                        String finalTKeyword = tKeyword;
                        List<String> sqls = Lists.newArrayList();
                        for (String s : split) {
                            final String s1 = keywordLikeSql(s, finalTKeyword);
                            sqls.add(s1);
                        }
                        StringBuilder sb = new StringBuilder();
                        for (String sql : sqls) {
                            if (sb.length() != 0) {
                                sb.append(" OR ");
                            }
                            sb.append(sql);
                        }
                        final String s = sb.toString();
                        if (!StringUtil.isEmpty(s)) {
                            addQuery(" AND ", "(" + s + ")");
                        }
//                        Arrays.asList(split).forEach(item -> {
//                            addKeywordFilterUseLike(item, finalTKeyword);
//                        });
                    } else {
                        keyword = tKeyword;
                    }
                }
                break;
            case SearchType.LIKE:
                String value = getFieldStringValue(field, paramVo);
                if (StringUtils.isNotBlank(value)) {
                    addLikeQuery(columnName, value.trim());
                }
                break;
            case SearchType.FILTER:
                if (annotation.filterDir() != FilterDirEnum.FILTER_DIR_NONE) {
                    String fieldStringValue = getFieldStringValue(field, paramVo);
                    if (!StringUtil.isAnyEmptyNew(columnName, fieldStringValue)) {
                        filterList
                            .add(columnName + annotation.filterDir().getCode()
                                + fieldStringValue);
                    }
                }
                break;
            case SearchType.FILTER_DATA_RANGE:
                String fieldStringValue = getFieldStringValue(field, paramVo);
                addFilterDateRange(columnName, fieldStringValue, annotation.includeEndDay());
                break;
            case SearchType.ORDER:
                String fieldOrder = getFieldStringValue(field, paramVo);
                if (!StringUtil.isAnyEmptyNew(columnName, fieldOrder)) {
                    sortMap.putAll(SortMappingUtils.parseOrderList(fieldOrder));
                }
                break;
            case SearchType.DISTINCT_FIELD:
                final String booleanStr = getFieldStringValue(field, paramVo);
                try {

                    if (Boolean.valueOf(booleanStr)) {
                        distinctField = annotation.label();
                    }
                } catch (Exception e) {
                    log.error("生成SearchQuery错误,DISTINCT_FIELD:lable:{},value:{},columnName:{}", annotation.label(),
                        booleanStr, columnName);
                }
            case SearchType.SEGEMNT:
                final String segment = getFieldStringValue(field, paramVo);
                if (!StringUtils.isBlank(segment)) {
                    segmentMap.put(columnName, segment);
                }
                break;
            default:
                break;
        }
    }

    public void addFilterDateRange(String field, String dateRange, Boolean includeEndDay) {
        if (org.apache.commons.lang3.StringUtils.isBlank(field) || StringUtils.isBlank(dateRange)) {
            return;
        }
        Date[] dates = DateUtils.parseDateRange(dateRange);
        if (dates == null && dates.length != 2) {
            return;
        }
        if (includeEndDay && null != dates[1]) {
            Calendar end = Calendar.getInstance();
            end.setTime(dates[1]);
            end.add(Calendar.DATE, 1);
            end.add(Calendar.SECOND, -1);//当天的最后一秒
            dates[1] = end.getTime();
        }
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if (dates[0] != null) {
            filterList.add(field + ">=" + String.valueOf(format.format(dates[0])));
        }
        if (dates[1] != null) {
            filterList.add(field + "<=" + String.valueOf(format.format(dates[1])));
        }
    }


    /**
     * 添加时间范围查询条件
     */
    public void addFilterDateRange(String field, String dateRange) {
        addFilterDateRange(field, dateRange, false);
    }

    /**
     * 添加关键字查询条件，
     *
     * @param field 需要查询的字段
     * @param keyword 关键字
     */
    public void addKeywordFilterUseLike(String field, String keyword) {
        if (org.apache.commons.lang3.StringUtils.isBlank(field) || org.apache.commons.lang3.StringUtils
            .isBlank(keyword)) {
            return;
        }
        StringBuilder sb = new StringBuilder(field.trim()).append(" LIKE \"%")
            .append(keyword.trim()).append("%\" ");
        addQuery("OR", sb.toString());
    }

    /**
     * 准备keyword 的sql
     */
    private String keywordLikeSql(String field, String keyword) {
        if (org.apache.commons.lang3.StringUtils.isBlank(field) || org.apache.commons.lang3.StringUtils
            .isBlank(keyword)) {
            return "";
        }
        StringBuilder sb = new StringBuilder(field.trim()).append(" LIKE \"%")
            .append(keyword.trim()).append("%\" ");
        return sb.toString();
    }

    /**
     * 添加复杂查询语句
     *
     * @param con 连接词 or  and
     * @param sql 查询的条件
     */
    public void addQuery(String con, String sql) {
        boolean flag = StringUtils.isEmpty(querys);
        if ("OR".equals(con.trim()) || "AND".equals(con.trim())) {
            querys += flag ? sql : " " + con + " " + sql;
        }
    }

    /**
     * @param con OR AND 连接词
     * @param column 字段名
     * @param values 值
     */
    public void inQuery(String con, String column, List<String> values) {
        if (!CollectionUtils.isEmpty(values)) {
            StringBuilder sb = new StringBuilder(column + " IN [");
            boolean flag = false;
            for (String value : values) {
                if (flag) {
                    sb.append(",");
                }
                flag = true;
                sb.append("\"");
                sb.append(value);
                sb.append("\"");
            }
            sb.append("] ");
            addQuery(con, sb.toString());
        }

    }


    /**
     * 添加模糊查询
     */
    private void addLikeQuery(String column, String value) {
        String str = column + " LIKE \"%" + value + "%\"";
        addQuery("AND", str);
    }

    /**
     * 添加likevalue
     */
    public void addRawLikeQuery(String column, String likeValue) {
        addQuery("AND", column + " LIKE " + "\"" + likeValue + "\"");
    }

    private void addToMap(Field field, T paramVo, String columnName,
        Map<String, String> map) {
        String fieldStringValue = getFieldStringValue(field, paramVo);
        if (StringUtils.isNotEmpty(fieldStringValue)) {
            map.put(columnName, fieldStringValue);
        }
    }

    private String getFieldStringValue(Field field, T paramVo) {
        Object fieldValue = ReflectionUtils.getFieldValue(paramVo, field);
        //如果是 类对象有比较尴尬了，，
        if (null != fieldValue) {
            if (fieldValue instanceof Date) {
                Date d = (Date) fieldValue;
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                return String.valueOf(format.format(d));
            }
            String value = String.valueOf(fieldValue);
            return value;
        }
        return null;
    }

    public void setCurrentIndex(Integer currentIndex) {
        this.currentIndex = currentIndex;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }


    public static String getColumnName(Class cls, Field fields) {
        Map<String, String> classColumnMap = PO_FIELD_COLUMN.get(cls.getName());
        if (classColumnMap == null) {
            classColumnMap = Maps.newConcurrentMap();
            PO_FIELD_COLUMN.put(cls.getName(), classColumnMap);
        }

        String label = classColumnMap.get(fields.getName());
        if (StringUtils.isEmpty(label)) {
            SearchParam ann = fields.getAnnotation(SearchParam.class);
            String la = null;
            if (ann != null && StringUtils.isNotEmpty(ann.label())) {
                classColumnMap.put(fields.getName(), ann.label());
                la = ann.label();
            } else {
                String value = StringUtils.camelToUnderline(fields.getName());
                classColumnMap.put(fields.getName(), value);
                la = value;
            }
            return la;
        } else {
            return label;
        }
    }


    public void addAndMap(String key, String value) {
        andMap.put(key, value);
    }

    public void addOrMap(String key, List<String> value) {
        orMap.put(key, value);
    }

    public void addAggregate(Aggregate aggregate) {
        this.aggregate.add(aggregate);
    }

    public void addAggregate(List<Aggregate> aggregate) {
        this.aggregate.addAll(aggregate);
    }

    public void addSort(String key, String value) {
        sortMap.put(key, value);
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public void addFilter(String filterStr) {
        filterList.add(filterStr);
    }

    public void addNestQuery(SearchNestQueryDTO nestQueryDTO) {
        this.nestQueryList.add(nestQueryDTO);
    }
}
