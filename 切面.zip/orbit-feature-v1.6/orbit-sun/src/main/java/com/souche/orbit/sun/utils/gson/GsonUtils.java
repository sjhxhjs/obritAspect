package com.souche.orbit.sun.utils.gson;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import java.lang.reflect.Type;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * Gson 空字符串会转换为null
 * @author jinrenhua
 *
 */
public class GsonUtils {

    private static Gson gson;

    static {
        gson =
                new GsonBuilder().serializeNulls().setDateFormat("yyyy-MM-dd")
                        .registerTypeAdapterFactory(new GsonEmptyToNullStringAdapterFactory())
                        .registerTypeAdapter(Timestamp.class, new GsonTsTypeAdapter())
                        .create();
    }
    /**
     * if param is empty string ，param to null
     * @param obj
     * @param classOfT
     * @return
     */
    public static <T> T beanCopy(Object obj, Class<T> classOfT) {
        if (obj == null) {
            return null;
        }
        // 特殊字符去除
        String json = toJson(obj).replaceAll("[\ud800\udc00-\udbff\udfff\ud800-\udfff]", "");

        return fromJson(json, classOfT);
    }
    
    public static <T> List<T> toBeanListCopy(Object obj, Class<T> clazz) throws Exception {
        List<T> lst = new ArrayList<T>();
        JsonArray array = new JsonParser().parse(toJson(obj)).getAsJsonArray();
        for (final JsonElement elem : array) {
            lst.add(gson.fromJson(elem, clazz));
        }
        return lst;
    }

    public static String toJson(Object src) {
        if (null == src) {
            return null;
        }
        return gson.toJson(src);
    }

    public static <T> T fromJson(String json, Class<T> classOfT) {
        if (null == json) {
            return null;
        }
        return gson.fromJson(json, classOfT);
    }

    public static <T> T fromJson(String json, Type typeOfT) {
        if (null == json) {
            return null;
        }
        return gson.fromJson(json, typeOfT);
    }

    public static <T> T toBean(String json, Class<T> clazz) {
        return gson.fromJson(json, clazz);
    }

    public static <T> T objectToBean(String object, Class<T> clazz) {
        return gson.fromJson(toJson(object), clazz);
    }

    public static String toJsonString(Object obj) {
        return gson.toJson(obj);
    }

    public static <T> List<T> toBeanList(String json, Class<T> clazz) throws Exception {
        List<T> lst = new ArrayList<T>();
        JsonArray array = new JsonParser().parse(json).getAsJsonArray();
        for (final JsonElement elem : array) {
            lst.add(gson.fromJson(elem, clazz));
        }
        return lst;
    }

}
