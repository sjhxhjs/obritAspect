package com.souche.orbit.sun.cache;

/**
 * @author SuperDaFu
 * @date 2018/10/15 下午5:06
 */

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Suggest to use dao
 *
 * Marks a method as to cache the result from target method
 *
 * Temporary support only bean
 *
 * <p>
 * The cache key will generater from cache group,current method name and parameters that passed to
 * the method
 */
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface Cache {

    /**
     * Cache group of current result will be stored.
     *
     * @return String cache group name
     */
    String group() default "default";

    /**
     * The prefix of cache key.
     *
     * @return String
     */
    String prefix();

    /**
     * Whether update or save the cache. Temporary support only bean
     *
     * <P>
     * Set true to update cache when data has been changed
     *
     * @return boolean true - will update cache after the method invocation; false - will NOT update
     *         cache
     */
    boolean update() default false;

    /**
     * object for cache in index.
     *
     * @return int
     */
    int cacheObjectIndex() default 0;

    /**
     * update the cache key
     *
     * @return Combination of key collection
     */
    String key() default "id";

    /**
     * clear the cache keys
     * <p>
     * Each value represents a key combination, combination key separator is ","
     *
     * @return Combination of key collection
     */
    String[] clearKeys() default {};

    /**
     * cache expiredTime
     *
     * @return int
     */
    int cacheTime() default 60 * 60;

    /**
     * Custom reflection
     * @return
     */
    Class<?> clazz() default String.class;
}
