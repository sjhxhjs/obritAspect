package com.souche.orbit.sun.eunm.behavior;

import com.souche.optimus.common.util.StringUtil;
import com.souche.orbit.sun.eunm.BasicEnumToDictionary;
import com.souche.orbit.sun.eunm.EnumValue;
import java.util.Map;
import org.springframework.stereotype.Component;

/**
 * @author wdf
 */
@Component("DefaultEnumInject")
public class EnumDictionaryInjectBehavior implements EnumInjectBehavior {

    @Override
    public String getValue(EnumValue enumValue, Object relateValue) {
        if (StringUtil.isEmpty(enumValue.key())) {
            return null;
        }
        //根据关联code字段名获取code值
        //根据key 获取枚举转字典map
        String key = null;
        if(enumValue.version()==0)
        {
            key = enumValue.key();
        }else {
            key = BasicEnumToDictionary.getDicKey(enumValue.key(), enumValue.version());
        }
        if (org.apache.commons.lang3.StringUtils.isBlank(key)) {
            return null;
        }
        Map<String, String> dicMap = BasicEnumToDictionary.basicDic.get(key);
        if (null == dicMap) {
            return null;
        }
        return dicMap.get(relateValue);
    }
}
