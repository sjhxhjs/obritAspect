package com.souche.orbit.sun.check.modes;

import com.souche.orbit.sun.check.CheckMode;
import com.souche.orbit.sun.check.CheckParam;
import com.souche.orbit.sun.exception.ExceptionUtils;
import java.util.regex.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * @author SuperDaFu
 * @date 2018/9/20 下午3:53
 */
@Slf4j
public class MobilePhoneCheckMode implements CheckMode {

    private static final Pattern patter = Pattern.compile("^([1][0-9]{10})|()$");
    //中间带横杠
    private static final Pattern patter2 = Pattern.compile("^([1](\\d{2}))-(\\d{4})-(\\d{4})$");
    //中间空格
    private static final Pattern patter3 = Pattern.compile("^([1](\\d{2})) (\\d{4}) (\\d{4})$");

    @Override
    public boolean check(Object value, CheckParam checkParam) {
        String str = value == null ? "" : String.valueOf(value);
        if (StringUtils.isNotEmpty(str)) {
            return patter.matcher(str).matches()
                || patter2.matcher(str).matches()
                || patter3.matcher(str).matches();
        }
        return true;
    }

    @Override
    public void error(Object value, String defaultErrorMsg) {
        throw ExceptionUtils.fail(defaultErrorMsg+"[手机号校验失败]");
    }

}
