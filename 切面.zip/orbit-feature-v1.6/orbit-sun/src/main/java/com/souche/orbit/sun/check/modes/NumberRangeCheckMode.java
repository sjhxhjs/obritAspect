package com.souche.orbit.sun.check.modes;

import com.souche.orbit.sun.check.CheckMode;
import com.souche.orbit.sun.check.CheckParam;
import com.souche.orbit.sun.exception.ExceptionUtils;
import com.souche.orbit.sun.utils.RangeStrUtils;
import java.math.BigDecimal;
import lombok.extern.slf4j.Slf4j;

/**
 * @author SuperDaFu
 * @date 2018/9/21 下午2:56
 */
@Slf4j
public class NumberRangeCheckMode implements CheckMode {

    @Override
    public boolean check(Object value, CheckParam checkParam) {
        String str = value == null ? "" : String.valueOf(value);
        try {
            BigDecimal bigDecimal = new BigDecimal(str);
            return RangeStrUtils.checkRange(checkParam.range(), bigDecimal);
        } catch (Exception e) {
            log.error("NumberRangeCheckMode 检查时异常", e);
            return false;
        }
    }

    @Override
    public void error(Object value, String defaultErrorMsg) {
        throw ExceptionUtils.fail(defaultErrorMsg + " [数字不在范围内]");
    }
}
