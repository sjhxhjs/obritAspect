package com.souche.orbit.sun.dto;

import com.souche.optimus.common.annotation.Field;
import java.util.List;
import lombok.Data;

/**
 * @author SuperDaFu
 * @date 2018/10/16 上午10:36
 */
@Data
public class FilterDTO {

    @Field("名字")
    private String name;
    @Field("后台key")
    private String key;
    @Field("值")
    private List<FilterDTO> content;
}
