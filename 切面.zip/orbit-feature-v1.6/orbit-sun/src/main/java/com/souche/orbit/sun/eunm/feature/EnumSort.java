package com.souche.orbit.sun.eunm.feature;

/**
 * @author SuperDaFu
 * @date 2018/10/11 下午3:24
 */
public interface EnumSort extends EnumVersion{
    /**
     * 排序支持，进行数据比较，，默认按照枚举格式进行排序
     * @param obj
     * @return
     */
    Integer compare(EnumSort obj);
}
