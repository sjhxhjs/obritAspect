package com.souche.orbit.sun.eunm;

import com.souche.orbit.sun.eunm.behavior.EnumDictionaryInjectBehavior;
import com.souche.orbit.sun.eunm.behavior.EnumInjectBehavior;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@Inherited
public @interface EnumValue {
    
    /**
     * enum key
     * @return
     */
    String key() default "";
    /**
     * 层级加载父节点
     * @return
     */
    String parentKey() default "";
    
    /**
     * 关联code
     * @return
     */
    String relateCode();

    /**
     * 自定义注入行为
     */
    Class<? extends EnumInjectBehavior> enumInjectBehavior() default EnumDictionaryInjectBehavior.class;

    /**
     * 自定义注入行为时，实现类不在当前项目里
     * @return
     */
    String enumInjectBehaviorBeanName() default "";

    int version() default 0;

}
