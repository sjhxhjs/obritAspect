package com.souche.orbit.sun.eunm;

import com.souche.optimus.common.page.Page;
import com.souche.optimus.common.util.StringUtil;
import com.souche.orbit.sun.eunm.behavior.EnumInjectBehavior;
import com.souche.orbit.sun.utils.ReflectionUtils;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

/**
 * 枚举value 注入拦截
 *
 * @author jinrenhua
 */
@Slf4j
@Aspect
public class EnumInjectionAspect  {



    @AfterReturning(value = "@annotation(com.souche.orbit.sun.eunm.EnumInjection)", returning = "result")
    public void afterReturningAdvice(JoinPoint joinPoint, Object result) throws Throwable {
        if (null == result) {
            return;
        }
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        log.debug("dictionary inject start,method:{} beforeValue:{}", method.getName(), result);

        EnumInjection enumInjection = method.getAnnotation(EnumInjection.class);
        EnumInjectionUtils.parseInjectClass(result, enumInjection);
    }


}