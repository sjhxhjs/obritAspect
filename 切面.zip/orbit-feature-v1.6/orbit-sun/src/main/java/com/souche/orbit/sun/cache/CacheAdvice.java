package com.souche.orbit.sun.cache;//package com.souche.lease.base.cache;

import com.souche.orbit.sun.OrbitSunConstant;
import com.souche.orbit.sun.utils.StringUtils;
import com.souche.orbit.sun.utils.gson.GsonUtils;
import java.lang.reflect.Method;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.reflect.MethodUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 处理方法执行前后的缓存逻辑
 */
@Slf4j
public class CacheAdvice implements MethodInterceptor {

    private static final Logger LOGGER = LoggerFactory.getLogger(CacheAdvice.class);

    private static final String SEPARATOR = ",";

    @Override
    public Object invoke(MethodInvocation invocation) throws Throwable {

        Object[] param = invocation.getArguments();

        Class<?> targetClass = invocation.getThis().getClass();
        Method ifaceMethod = invocation.getMethod();
        Method targetMethod =
            MethodUtils.getAccessibleMethod(targetClass, ifaceMethod.getName(), ifaceMethod.getParameterTypes());

        // Get annotation
        Cache cls = targetMethod.getAnnotation(Cache.class);
        if (cls == null) {
            // Ignore current method
            return invocation.proceed();
        }

        Object obj = null;

        if (!cls.update()) {// No need to update cache
            String key = MemCacheTool.getCacheKey(cls.prefix(), cls.group(), param);
            try {
                String cacheInfo = MemCacheTool.get(key);// Get from cache first
                if (cacheInfo != null) {// Find from cache
                    if (targetMethod.getReturnType().equals(OrbitSunConstant.CLASS_STRING)) {
                        return cacheInfo;
                    } else if (targetMethod.getReturnType().equals(OrbitSunConstant.CLASS_INTEGER)) {
                        return Integer.valueOf(cacheInfo);
                    }
                    if (targetMethod.getReturnType().equals(OrbitSunConstant.CLASS_LIST) && null != cls.clazz()) {
                        return GsonUtils.toBeanList(cacheInfo, cls.clazz());
                    }
                    final Class<?> returnType = targetMethod.getReturnType();
                    return GsonUtils.toBean(cacheInfo, returnType);
                }
            } catch (Exception e) {
                LOGGER.error("cache gson to bean error", e);
            }

            obj = invocation.proceed();
            setIntoCache(key, obj, cls.cacheTime());

        } else {

            obj = invocation.proceed();

            try {
                Map<String, Object> value =
                    GsonUtils.toBean(GsonUtils.toJson(param[cls.cacheObjectIndex()]), Map.class);

                if (value != null && value.get(cls.key()) != null && !value.get(cls.key()).equals("")) {
                    String key = MemCacheTool.getCacheKey(cls.prefix(), cls.group(), value.get(cls.key()));

                    clearInfoCache(cls.clearKeys(), value, cls.prefix(), cls.group());

                    setIntoCache(key, value, cls.cacheTime());
                }

            } catch (Exception e) {
                LOGGER.error("update cache gson to bean error", e);
            }

        }

        return obj;
    }


    /**
     * Check if value is null OR empty
     */
    private boolean isEmpty(Object value) {
        if (value == null) {
            return true;
        }
        try {
            if (CollectionUtils.sizeIsEmpty(value)) {
                return true;
            }
        } catch (IllegalArgumentException e) {
            // Ignore
        }
        return false;
    }

    /**
     * Save value to cache service if not empty, use SET operation
     */
    private void setIntoCache(String key, Object value, int expiredTime) {
        if (isEmpty(value)) {
            LOGGER.debug("Value is empty, will not save to cache, value=" + GsonUtils.toJson(value));
            return;
        }
        try {
            if (value instanceof String) {
                MemCacheTool.set(key, String.valueOf(value), expiredTime);
            } else if (value instanceof Integer) {
                MemCacheTool.set(key, String.valueOf(value), expiredTime);
            } else {
                MemCacheTool.set(key, GsonUtils.toJson(value), expiredTime);
            }
        } catch (Exception e) {
            LOGGER.error("CacheAdvice.setIntoCache error ", e);
        }


    }

    /**
     * update value to cache service if not empty, Only the cache the bean
     */
    private void setIntoCache(String key, Map<String, Object> value, int expiredTime) {
        if (isEmpty(value)) {
            LOGGER.debug("Value is empty, will not save to cache, value=" + GsonUtils.toJson(value));
            return;
        }

        MemCacheTool.set(key, GsonUtils.toJson(value), expiredTime);
    }

    /**
     * clear value to cache service if not empty, Only the cache the bean
     */

    private void clearInfoCache(String[] clearKeys, Map<String, Object> value, String prefix, String group) {
        if (clearKeys != null && clearKeys.length > 0) {
            for (String keys : clearKeys) {
                try {
                    if (StringUtils.isEmpty(keys)) {
                        continue;
                    }
                    String key = null;
                    if (keys.contains(SEPARATOR)) {

                        String[] ks = keys.split(SEPARATOR);
                        StringBuilder sb = new StringBuilder();
                        for (String k : ks) {
                            sb.append(value.get(String.valueOf(k)));
                        }

                        key = MemCacheTool.getCacheKey(prefix, group, sb.toString());
                    } else {
                        key = MemCacheTool.getCacheKey(prefix, group, value.get(keys));
                    }
                    MemCacheTool.del(key);
                } catch (Exception e) {
                    log.error("CacheAdvice:", e);
                }

            }
        }
    }
}

