package com.souche.orbit.sun.dto;

import com.souche.optimus.common.page.Page;
import lombok.Data;

/**
 * @author honglei
 * @date 2018/11/21 下午2:51
 */
@Data
public class ResultDTO<T> {

    /**
     * 操作结果id
     */
    private String resultId;
    /**
     * 操作结果，是否成功，用于返回boolean 值的情况
     */

    private Boolean state;

    private String status;

    private String statusName;

    private Page<T> page;
    public ResultDTO(){}

    public ResultDTO(String resultId){
        this.resultId = resultId;
    }

    public static ResultDTO success(String resultId) {
        ResultDTO resultDTO = new ResultDTO();
        resultDTO.setResultId(resultId);
        return resultDTO;
    }

    public static ResultDTO success(boolean b) {
        if (b) {
            ResultDTO aTrue = success("true");
            aTrue.setState(b);
            return aTrue;
        }else{
            ResultDTO aFalse = success("false");
            aFalse.setState(b);
            return aFalse;
        }
    }
}
