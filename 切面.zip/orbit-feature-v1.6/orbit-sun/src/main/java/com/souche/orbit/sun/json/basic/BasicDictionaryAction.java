package com.souche.orbit.sun.json.basic;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.souche.optimus.common.util.StringUtil;
import com.souche.optimus.core.annotation.Json;
import com.souche.optimus.core.annotation.Param;
import com.souche.optimus.core.annotation.View;
import com.souche.orbit.sun.dto.KVDTO;
import com.souche.orbit.sun.eunm.BasicEnumToDictionary;
import com.souche.orbit.sun.exception.ExceptionUtils;
import com.souche.orbit.sun.json.param.DicParam;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import org.apache.commons.collections.CollectionUtils;

/**
 * @author SuperDaFu
 * @date 2018/9/11 上午10:36
 */
@Api(value = "basic dictionary", description = "枚举字段")
@View
public class BasicDictionaryAction {

    @ApiOperation(value = "根据版本号，获取对应的属性")
    public Map<String, String> queryDictionaryByCodeAndVersion(
        @Param(required = true, value = "code", desc = "枚举值的key") String code,
        @Param(value = "version", desc = "枚举的版本号") Integer version) {
        if (version != null) {
            if ((version & (version - 1)) != 0) {
                throw ExceptionUtils.fail("version版本号错误");
            }
        }
        return BasicEnumToDictionary.basicDic
            .get(BasicEnumToDictionary.getDicKey(code, version));

    }

    @ApiOperation(value = "根据枚举映射字典")
    public Map<String, String> queryDictionaryByCode(
        @Param(required = true, value = "code", desc = "编码的key") String code) {

        Map<String, String> stringStringMap = BasicEnumToDictionary.basicDic.get(code);
        return stringStringMap;
    }

    @ApiOperation(value = "一次性返回多个枚举")
    public Map<String, List<KVDTO>> queryDictionaryByDicParams(
        @Json(value = "params", array = DicParam.class) List<DicParam> params) {
        Map<String, List<KVDTO>> resultMap = Maps.newLinkedHashMap();

        if (CollectionUtils.isNotEmpty(params)) {
            for (DicParam param : params) {
                if (StringUtil.isNotEmpty(param.getCode())) {
                    if (null != param.getVersion()) {
                        final Map<String, String> stringStringMap = BasicEnumToDictionary.basicDic
                            .get(BasicEnumToDictionary.getDicKey(param.getCode(), param.getVersion()));
                        List<KVDTO> lists = Lists.newLinkedList();
                        stringStringMap.forEach((key, value) -> {
                            KVDTO kv = new KVDTO();
                            kv.setValue(key);
                            kv.setKey(key);
                            kv.setLabel(value);
                            lists.add(kv);
                        });
                        resultMap.put(param.getCode(), lists);
                    } else {
                        final LinkedList<KVDTO> list = Lists.newLinkedList();
                        final Map<String, String> stringStringMap = BasicEnumToDictionary.basicDic.get(param.getCode());
                        stringStringMap.forEach((key, value) -> {
                            KVDTO kv = new KVDTO(key, key);
                            kv.setLabel(value);
                            list.add(kv);
                        });
                        resultMap.put(param.getCode(), list);
                    }
                }
            }
        }
        return resultMap;
    }
}
