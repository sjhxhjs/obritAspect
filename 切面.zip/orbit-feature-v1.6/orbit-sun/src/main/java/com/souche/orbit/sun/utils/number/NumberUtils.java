package com.souche.orbit.sun.utils.number;


import static com.souche.orbit.sun.OrbitSunConstant.DEFAULT_DIV_SCALE;
import static com.souche.orbit.sun.OrbitSunConstant.DEFAULT_DOWN_SCALE;
import static com.souche.orbit.sun.OrbitSunConstant.DEFAULT_FRONT_SCALE;

import com.souche.optimus.common.util.StringUtil;
import java.math.BigDecimal;

/**
 * @author SuperDaFu
 * @date 2018/9/10 下午5:21
 */
public class NumberUtils {

    /**
     * 二进制中1的个数
     */
    public static int binary1Count(int n) {

        int count = 0;
        while (n > 0) {
            ++count;
            n = (n - 1) & n;
        }
        return count;
    }

    public static int binaryBitCount(int n) {
        return Integer.toBinaryString(n).length();
    }

    /**
     * 将万 转换成 一  例如 万公里 转换为公里
     */
    public static BigDecimal convertMiriadeToOne(BigDecimal wanNumber) {
        if (wanNumber == null) {
            return null;
        }
        return wanNumber.multiply(new BigDecimal(10000));
    }

    /**
     * 将 一 转换车 万
     */
    public static String convertOneToMiriabeStr(Integer value) {
        if (value == null) {
            return "";
        }
        return new BigDecimal(value).divide(new BigDecimal(10000), 4, BigDecimal.ROUND_UP).stripTrailingZeros()
            .toPlainString();
    }

    /**
     * 将 一 转换 万 数字
     */
    public static BigDecimal convertOneToMiriabe(BigDecimal value) {
        if (value == null) {
            return null;
        }
        return new BigDecimal(
            value.divide(new BigDecimal(10000), 4, BigDecimal.ROUND_UP).stripTrailingZeros().toPlainString());
    }

    public static String convertOneToMiriabeStr(Integer value, String unit) {
        String s = convertOneToMiriabeStr(value);
        if (StringUtil.isEmpty(s)) {
            return "";
        } else {
            return s + unit;
        }
    }

    public static boolean equals(BigDecimal a, BigDecimal b) {
        return a.compareTo(b) == 0;
    }

    /**
     * 将数字转化为2位小数，精度采用进位制（小数点第三位），如：
     * 100.001转化位100.01
     * 100.0009转化位100.00
     */
    public static BigDecimal transferTwoScale(BigDecimal amount) {
        return transferScale(amount, 2);
    }

    public static BigDecimal transferScale(BigDecimal amount, int scale) {
        return amount.setScale(scale + 1, BigDecimal.ROUND_DOWN).setScale(scale, BigDecimal.ROUND_UP);
    }
    public static String transferTwoScaleStr(BigDecimal am) {

        return transferScaleStr(am, 2);
    }
    public static String transferScaleStr(BigDecimal am,int scale){
        return transferScale(am, scale).stripTrailingZeros().toPlainString();
    }

    public static boolean between(BigDecimal value, BigDecimal max, BigDecimal min) {
        if (value.compareTo(max) < 1 && value.compareTo(min) > -1) {
            return true;
        }
        return false;
    }

    public static boolean between(Integer target, Integer start, Integer end) {
        if (target < start || target > end) {
            return false;
        }
        return true;
    }

    public static BigDecimal divide(BigDecimal bigDecimal, BigDecimal b1) {
        return bigDecimal.divide(b1, DEFAULT_DIV_SCALE, BigDecimal.ROUND_UP);
    }

    public static BigDecimal divide(BigDecimal bigDecimal, Integer b1) {
        return bigDecimal.divide(new BigDecimal(b1), DEFAULT_DIV_SCALE, BigDecimal.ROUND_UP);
    }
}
