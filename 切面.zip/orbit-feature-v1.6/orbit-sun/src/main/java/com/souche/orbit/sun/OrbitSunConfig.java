package com.souche.orbit.sun;

import com.souche.optimus.redis.RedisCountRepository;
import com.souche.optimus.redis.RedisListRepository;
import com.souche.optimus.redis.RedisLock;
import com.souche.optimus.redis.RedisValueRepository;
import com.souche.orbit.sun.access.data.AccessPermissionsDaoAspect;
import com.souche.orbit.sun.check.CheckModeRegister;
import com.souche.orbit.sun.check.CheckParamExecutor;
import com.souche.orbit.sun.check.modes.CarPlateCheckMode;
import com.souche.orbit.sun.check.modes.MobilePhoneCheckMode;
import com.souche.orbit.sun.check.modes.NumberCheckModel;
import com.souche.orbit.sun.check.modes.NumberRangeCheckMode;
import com.souche.orbit.sun.check.modes.PhoneCheckMode;
import com.souche.orbit.sun.check.modes.StringLengthCheckMode;
import com.souche.orbit.sun.check.modes.StringLengthRangeCheckMode;
import com.souche.orbit.sun.eunm.EnumInjectionAspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;

/**
 * @author SuperDaFu
 * @date 2018/9/20 下午4:00
 */
@Configuration
@ImportResource(locations = "classpath:orbit-sun-config.xml")
@PropertySource(value = "classpath:orbit-config.properties")
@ComponentScan("com.souche.orbit")
@EnableAspectJAutoProxy(proxyTargetClass = true)
public class OrbitSunConfig {

    /**
     * 参数校验执行器
     */
    @Bean(name = "checkParamExecutor")
    public CheckParamExecutor initCheckParamExecutor(CheckModeRegister register) {

        //添加默认的参数校验执行规则
        register.addCheckMode(OrbitSunConstant.CHECK_MODE_STR_LENGTH, new StringLengthCheckMode());
        register.addCheckMode(OrbitSunConstant.CHECK_MODE_STR_LENGTH_RANGE, new StringLengthRangeCheckMode());
        register.addCheckMode(OrbitSunConstant.CHECK_MODE_CAR_PLATE, new CarPlateCheckMode());
        register.addCheckMode(OrbitSunConstant.CHECK_MODE_MOBILE_PHONE, new MobilePhoneCheckMode());
        register.addCheckMode(OrbitSunConstant.CHECK_MODE_PHONE, new PhoneCheckMode());
        register.addCheckMode(OrbitSunConstant.CHECK_MODE_NUMBER_RANGE, new NumberRangeCheckMode());
        register.addCheckMode(OrbitSunConstant.CHECK_NUMBER, new NumberCheckModel());
        CheckParamExecutor executor = new CheckParamExecutor();
        executor.setCheckModeRegister(register);
        return executor;
    }



    @Bean
    public EnumInjectionAspect enumInjectionAspect() {
        return new EnumInjectionAspect();
    }

    /**************Redis 相关配置***********/
    @Value("${orbit.redis.enable}")
    private Boolean jredisEnable;

    @Value("${orbit.redis.host}")
    private String redisHost;

    @Value("${orbit.redis.port}")
    private Integer redisPort;

    @Value("${orbit.redis.password}")
    private String redisPassword;

    @Value("${orbit.cache.keyPrefix}")
    private String cacheKeyPrefix;

    @Bean
    public JedisConnectionFactory jedisConnectionFactory() {
        if (jredisEnable) {
            JedisConnectionFactory jedisConnectionFactory = new JedisConnectionFactory();
            jedisConnectionFactory.setUsePool(true);
            jedisConnectionFactory.setHostName(redisHost);
            jedisConnectionFactory.setPort(redisPort);
            jedisConnectionFactory.setPassword(redisPassword);
            return jedisConnectionFactory;
        }
        return null;
    }

    @Bean
    public RedisTemplate redisTemplate(@Autowired RedisConnectionFactory redisConnectionFactory) {
        if (jredisEnable) {
            RedisTemplate redisTemplate = new RedisTemplate();
            redisTemplate.setConnectionFactory(redisConnectionFactory);
            redisTemplate.setKeySerializer(new StringRedisSerializer());
            redisTemplate.setValueSerializer(new StringRedisSerializer());
            redisTemplate.setDefaultSerializer(new StringRedisSerializer());
            return redisTemplate;
        }
        return null;
    }

    @Bean
    public RedisListRepository redisListRepository(@Autowired RedisTemplate redisTemplate) {
        RedisListRepository redisListRepository = new RedisListRepository();
        redisListRepository.setKeyPrefix(cacheKeyPrefix);
        redisListRepository.setRedisTemplate(redisTemplate);
        return redisListRepository;
    }

    @Bean
    public RedisCountRepository redisCountRepository(@Autowired RedisTemplate redisTemplate) {
        RedisCountRepository redisCountRepository = new RedisCountRepository();
        redisCountRepository.setKeyPrefix(cacheKeyPrefix);
        redisCountRepository.setRedisTemplate(redisTemplate);
        return redisCountRepository;
    }

    @Bean
    public RedisValueRepository redisValueRepository(@Autowired RedisTemplate redisTemplate) {
        RedisValueRepository redisValueRepository = new RedisValueRepository();
        redisValueRepository.setKeyPrefix(cacheKeyPrefix);
        redisValueRepository.setRedisTemplate(redisTemplate);
        return redisValueRepository;
    }

    @Bean
    public RedisLock redisLock(@Autowired RedisTemplate redisTemplate) {
        RedisLock redisLock = new RedisLock();
        redisLock.setKeyPrefix(cacheKeyPrefix);
        redisLock.setRedisTemplate(redisTemplate);
        return redisLock;
    }

    /***************************c初始化Dao校验层**************/
    @Value("${access.permission.dao}")
    private boolean accessDao;

}
