package com.souche.orbit.sun.auth;

import com.alibaba.fastjson.JSONObject;
import com.souche.bumblebee.trace.SoucheTracer;
import com.souche.optimus.redis.RedisValueRepository;
import com.souche.orbit.sun.utils.StringUtils;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author SuperDaFu
 * @date 2018/12/25 下午4:21
 */
@Slf4j
@Component("authInfoHolderActuotar")
public class AuthInfoHolderActuotar {

    private ThreadLocal<Map<String, String>> threadLocal = new ThreadLocal<>();

    @Autowired
    public RedisValueRepository redisValueRepository;

    public void put(Map<String, String> map) {
        final String traceId = getTraceId();
        redisValueRepository.set(traceId, JSONObject.toJSONString(map), 60);
        threadLocal.set(map);
    }

    public void addKV(String key, String value) {
        final Map<String, String> real = getReal();
        if (real != null) {
            final String traceId = getTraceId();
            real.put(key, value);
            redisValueRepository.set(traceId, JSONObject.toJSONString(real), 60);
            threadLocal.set(real);
        }

    }

    public String getTraceId() {
        return SoucheTracer.getInstance().getTraceId();
    }

    /**
     * 登录用户的ID
     */
    public String userId() {
        return get("userId");
    }

    /**
     * 获取登录用户的账号
     */
    public String userName() {
        return get("userName");
    }

    /**
     * 获取登录用户的显示名
     */
    public String displayName() {
        return get("displayName");
    }

    /**
     * 获取登录的用户手机
     */
    public String userPhone() {
        return get("userPhone");
    }

    /**
     * 获取用户头像
     */
    public String headImg() {
        return get("headImg");
    }


    public String get(String key) {
        final Map<String, String> real = getReal();
        if (real != null) {
            final String string = real.get(key);
            log.debug("Authinfo 获取信息成功：{},traceId:{},data:{}", key, getTraceId(), string);
            return string;
        }
        return "";
    }

    public Map<String, String> getReal() {
        final Map<String, String> stringStringMap = threadLocal.get();
        if (stringStringMap == null) {
            final String traceId = getTraceId();
            if (redisValueRepository == null) {
                return null;
            }
            final String s = redisValueRepository.get(traceId);
            if (StringUtils.isNotEmpty(s)) {
                final Map map = JSONObject.parseObject(s, Map.class);
                threadLocal.set(map);
                return map;
            }
            return null;
        } else {
            return stringStringMap;
        }
    }

    public void clear() {
        final Map<String, String> stringStringMap = threadLocal.get();
        if (stringStringMap != null) {
            stringStringMap.clear();
        }
        redisValueRepository.delete(getTraceId());

    }


}
