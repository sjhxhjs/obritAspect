package com.souche.orbit.sun;

import java.util.List;

/**
 * @author SuperDaFu
 * @date 2019/2/20 上午10:08
 */
public class OrbitSunConstant {
    public static final Class<?> CLASS_STRING = String.class;
    public static final Class<?> CLASS_INTEGER = Integer.class;
    public static final Class<?> CLASS_LIST = List.class;
    /**
     * 计算时候的精度
     */
    public static final int DEFAULT_DIV_SCALE = 5;//计算时候的精度
    public static final int DEFAULT_FRONT_SCALE = 2;//显示精度
    public static final int DEFAULT_DOWN_SCALE = 3;//舍弃精度
    
    /**
     * sql
     */
    public static final String SQL_ORDER_TYPE_DESC = "desc";
    public static final String SQL_ORDER_TYPE_ASC = "asc";
    public static final String SQL_ORDER_FIELD_DATE_CREATE = "date_create";
    public static final String SQL_ORDER_FIELD_DATE_UPDATE = "date_update";
    
    
    
    /**
     * 索引 src
     */
    public static final String SEARCH_SRC_NAME = "orbit-sun";

    private static final String CHECK_PRESUFFIX = "orbit_sun_";
    /**
     * 校验规则 字符串固定长度
     */
    public static final String CHECK_MODE_STR_LENGTH = CHECK_PRESUFFIX + "check_mode_str_length";
    /**
     * 校验规则 字符串长度限制
     */
    public static final String CHECK_MODE_STR_LENGTH_RANGE = CHECK_PRESUFFIX + "check_mode_str_length_range";
    /**
     * 校验规则 数值类型长度限制
     */
    public static final String CHECK_MODE_NUMBER_RANGE = CHECK_PRESUFFIX + "check_mode_number_range";
    /**
     * 校验规则 车牌校验
     */
    public static final String CHECK_MODE_CAR_PLATE = CHECK_PRESUFFIX + "check_mode_car_plate";
    /**
     * 校验规则 手机号校验
     */
    public static final String CHECK_MODE_MOBILE_PHONE = CHECK_PRESUFFIX + "check_mode_mobile_phone";
    /**
     * 校验规则 座机校验
     */
    public static final String CHECK_MODE_PHONE = CHECK_PRESUFFIX + "check_mode_phone";

    /**
     * 检查是否未全数字
     */
    public static final String CHECK_NUMBER = CHECK_PRESUFFIX + "check_number";
}
