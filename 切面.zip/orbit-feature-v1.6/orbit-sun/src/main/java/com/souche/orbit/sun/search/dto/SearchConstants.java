package com.souche.orbit.sun.search.dto;

/**
 * @author SuperDaFu
 * @date 2019/2/28 下午2:09
 */
public class SearchConstants {
    public static final String LIKE = " LIKE ";
    public static final String UNLIKE = " UNLIKE ";
    public static final String IN = " IN ";
    public static final String NOT_IN = " NOT IN ";
    public static final String EQ = " = ";
    public static final String NOT_EQ = " != ";
    public static final String GT = " > ";
    public static final String GT_EQ = " >= ";
    public static final String LT = " < ";
    public static final String LT_EQ = " <= ";
}
