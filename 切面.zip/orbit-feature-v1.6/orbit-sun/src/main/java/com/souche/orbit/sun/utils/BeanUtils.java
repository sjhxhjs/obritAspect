package com.souche.orbit.sun.utils;

import com.souche.optimus.common.page.Page;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

@Slf4j
public class BeanUtils {


    /**
     * 将一个对象转化为另一个类型的对象
     * @param source
     * @param clazz
     * @param <T>
     * @param <M>
     * @return
     */
    public static <T,M> M copyProperties(T source, Class<M> clazz) {
        M target = null;
        if (source == null) {
            return target;
        }
        try {
            target = clazz.newInstance();
            org.springframework.beans.BeanUtils.copyProperties(source, target);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return target;
    }

    /**
     * 将某类型的列表转换为另一类型的列表
     * @param source
     * @param clazz
     * @param <T>
     * @param <M>
     * @return
     */
    public static <T,M> List<M> copyPropertiesList(List<T> source, Class<M> clazz) {
        if (source == null || CollectionUtils.isEmpty(source)) {
            return new ArrayList<>();
        }
        List<M> target = new ArrayList<>(source.size());
        for (T item : source) {
            try{
                M obj = clazz.newInstance();
                org.springframework.beans.BeanUtils.copyProperties(item, obj);
                target.add(obj);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
                return target;
            }
        }
        return target;
    }

    /**
     * Page转换
     * @param from
     * @param targetClazz
     * @param <M>
     * @param <T>
     * @return
     */
    public static <M,T> Page<T> copyPropertiesPage(Page<M> from, Class<T> targetClazz) {
        Assert.notNull(from);

        List<T> targetList = new ArrayList<>();
        if (!CollectionUtils.isEmpty(from.getItems())) {
            from.getItems().forEach(item -> {
                T instanceOfType = ReflectionUtils.createInstanceOfType(targetClazz, false);
                org.springframework.beans.BeanUtils.copyProperties(item, instanceOfType);
                targetList.add(instanceOfType);
            });
        }
        return new Page<>(from.getTotalNumber(), from.getCurrentIndex(), from.getPageSize(), targetList);
    }
}
