package com.souche.orbit.sun.utils;

import java.lang.reflect.Method;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import com.google.common.collect.Maps;

@Slf4j
public class ObjectUtils {
    
    public static String getFieldStringValueByName(String fieldName, Object o) {
        
        return StringUtils.valueOf(getFieldObjctValueByName(fieldName, o));
    }
    
    public static Object getFieldObjctValueByName(String fieldName, Object o) {
        try {
            String firstLetter = fieldName.substring(0, 1).toUpperCase();
            String getter = "get" + firstLetter + fieldName.substring(1);
            Method method = o.getClass().getMethod(getter, new Class[] {});
            return method.invoke(o, new Object[] {});
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        
        return null;
    }
    
    public static Map<String,Object> getFieldValueByNames(Object o,String...fieldNames) {
        
        Map<String,Object> resurl = Maps.newHashMap();
        try {
            Class<? extends Object> clazz = o.getClass();
            for(String fieldName : fieldNames){
                String firstLetter = fieldName.substring(0, 1).toUpperCase();
                String getter = "get" + firstLetter + fieldName.substring(1);
                Method method = clazz.getMethod(getter, new Class[] {});
                resurl.put(fieldName, method.invoke(o, new Object[] {}));
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        
        return resurl;
    }
    
}
