package com.souche.orbit.sun.access.data;

import com.alibaba.fastjson.JSONObject;
import java.util.List;
import java.util.Map;

/**
 * @author SuperDaFu
 * @date 2019/2/20 下午3:52
 */
public interface AccessPermissionsResolver {

    /**
     * 是否直接跳过该层校验
     * @return
     */
    default boolean skip(){
        return false;
    }

    /**
     * 检查用户是否登录
     */
    boolean checkLogin();

    /**
     * 获取需要校验的字段
     */
    List<String> getNeedCheckField();

    /**
     * 校验数据
     *
     * @param resultFieldValue 被校验数据的 被校验字段的值
     */
    void checkAccessPermissions(Map<String, Object> resultFieldValue);
}
