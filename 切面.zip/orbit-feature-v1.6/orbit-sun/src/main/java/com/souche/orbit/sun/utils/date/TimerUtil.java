package com.souche.orbit.sun.utils.date;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.apache.curator.shaded.com.google.common.base.Objects;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.souche.optimus.common.util.CollectionUtils;
import com.souche.orbit.sun.exception.OrbitExceptionBase;
import com.souche.orbit.sun.utils.date.bean.ExclusionDate;
import com.souche.orbit.sun.utils.date.bean.ExclusionDate.ExclusionDateTypeEnum;
import com.souche.orbit.sun.utils.date.bean.ExclusionTime;

/**
 * 计时器
 * @author jinrenhua
 * @date 2019年7月8日 下午4:39:11
 */
@Slf4j
public class TimerUtil {
    
    private static final List<String> weeks = Lists.newArrayList(
            ExclusionDateTypeEnum.SUNDAY.getCode(),
            ExclusionDateTypeEnum.MONDAY.getCode(),
            ExclusionDateTypeEnum.TUESDAY.getCode(),
            ExclusionDateTypeEnum.WEDNESDAY.getCode(),
            ExclusionDateTypeEnum.THURSDAY.getCode(),
            ExclusionDateTypeEnum.FRIDAY.getCode(),
            ExclusionDateTypeEnum.SATURDAY.getCode());
    
    /**
     * 计时器
     * @param start 开始时间
     * @param later 延迟时间（分钟）
     * @param exclusionDates（排除时间）
     * @return
     */
    public static Date calculator(Date start,int later,List<ExclusionDate> exclusionDates){
        Calendar instance = Calendar.getInstance();
        
        instance.setTime(start);
        
        int index = 0;
        
        List<ExclusionTime> times = getExclusionCustomTime(exclusionDates);
        
        Map<Integer,List<ExclusionDate>> groupWeek = getGroupWeek(exclusionDates);
        
        List<ExclusionTime> weekTimes = Lists.newArrayList();
        
        int day = 0;
        
        boolean init = false;
        
        int count = 0;
        
        int maxCount = 1000;
        
        while(later > index){
            
            boolean run = true;
//            System.out.println(DateUtils.formatDate(instance.getTimeInMillis(), "yyyy-MM-dd HH:mm:ss"));
            instance.add(Calendar.MINUTE, 1);
            long nextTime = instance.getTimeInMillis();
            //指定日期快进
            for(ExclusionTime t : times){
                if(nextTime >= t.getStartTime() && nextTime < t.getEndTime()){
//                    System.out.println("d start:"+DateUtils.formatDate(t.getStartTime(), "yyyy-MM-dd HH:mm:ss"));
//                    System.out.println("d end:"+DateUtils.formatDate(t.getEndTime(), "yyyy-MM-dd HH:mm:ss"));
                    int fastForward = getFastForward(nextTime,t.getEndTime());
                    instance.add(Calendar.MINUTE, fastForward);
                    run = false;
                    break;
                }
            }
            
            int w = instance.get(Calendar.DAY_OF_WEEK) - 1;
            
            //自然周
            if(run && groupWeek.get(w) != null){
                
                if(day == 0 || day != instance.get(Calendar.DAY_OF_MONTH)){
                    day = instance.get(Calendar.DAY_OF_MONTH);
                    weekTimes = getExclusionWeekTime(groupWeek.get(w),DateUtils.formatDate(nextTime, "yyyy-MM-dd"));
                    
                }
                
                //自然周快进
                for(ExclusionTime t : weekTimes){
                    if(nextTime >= t.getStartTime() && nextTime < t.getEndTime()){
                        int fastForward = getFastForward(nextTime,t.getEndTime());
                        instance.add(Calendar.MINUTE, fastForward);
                        run = false;
                        break;
                    }
                }
                
            }
            
            //自然周
            if(run){
                index++;
            }else if(count++ >= maxCount){
                throw new OrbitExceptionBase("计时器计算异常，请检查关闭计时!");
            }
            if(index == 0 && !init){
                long initTime = instance.getTimeInMillis();
                instance.setTimeInMillis(initTime/60000*60000);
                init = true;
            }
            
        }
        
        return instance.getTime();
    }
    
    /**
     * 快进时间
     * @param startTime
     * @param endTime
     * @return
     */
    private static int getFastForward(long startTime,long endTime){
        if(startTime < endTime){
            return (int)(endTime - startTime)/60000;
        }
        return 1;
    }
    
    
    /**
     * 自然周义时间处理
     * @param exclusionDates
     * @return
     */
    private static List<ExclusionTime> getExclusionWeekTime(List<ExclusionDate> exclusionDates,String date){
        if(CollectionUtils.isEmpty(exclusionDates)){
            return Lists.newArrayList();
        }
        List<ExclusionTime> times = Lists.newArrayList();
        for(ExclusionDate d : exclusionDates){
            try {
                //时间
                long startTime = DateUtils.strToTimeMillis("yyyy-MM-dd HH:mm:ss", date + " " + d.getStart());
                long endTime = DateUtils.strToTimeMillis("yyyy-MM-dd HH:mm:ss", date + " " + d.getEnd());
                if(endTime > startTime){
                    ExclusionTime t = new ExclusionTime(startTime,endTime);
                    times.add(t);
                }
            } catch (Exception e) {
                log.error("参数转换异常！",e);
            }
            
        }
        return times;
    }
    
    /**
     * 自然周分组
     * @param exclusionDates
     * @return
     */
    private static Map<Integer,List<ExclusionDate>> getGroupWeek(List<ExclusionDate> exclusionDates){
        if(CollectionUtils.isEmpty(exclusionDates)){
            return Maps.newHashMap();
        }
        Map<Integer,List<ExclusionDate>> groupWeek = Maps.newHashMap();
        
        for(ExclusionDate d : exclusionDates){
            if(weeks.contains(d.getType())){
                List<ExclusionDate> dates = groupWeek.get(Integer.valueOf(d.getType()));
                if(dates == null){
                    dates = Lists.newArrayList(d);
                    groupWeek.put(Integer.valueOf(d.getType()), dates);
                }else{
                    dates.add(d);
                    groupWeek.put(Integer.valueOf(d.getType()), dates);
                }
                
            }
        }
        return groupWeek;
    }
    
    /**
     * 自定义时间处理
     * @param ExclusionDates
     * @return
     */
    private static List<ExclusionTime> getExclusionCustomTime(List<ExclusionDate> exclusionDates){
        if(CollectionUtils.isEmpty(exclusionDates)){
            return Lists.newArrayList();
        }
        List<ExclusionTime> times = Lists.newArrayList();
        for(ExclusionDate d : exclusionDates){
            try {
                //时间戳
                if(Objects.equal(ExclusionDateTypeEnum.TIME_IN_MILLIS.getCode(), d.getType())){
                    long startTime = Long.valueOf(d.getStart());
                    long endTime = Long.valueOf(d.getEnd());
                    
                    
                    if(endTime > startTime){
                        ExclusionTime t = new ExclusionTime(startTime,endTime);
                        times.add(t);
                    }
                }else if(Objects.equal(ExclusionDateTypeEnum.TIME.getCode(), d.getType())){//日期时间
                    long startTime = DateUtils.strToTimeMillis("yyyy-MM-dd HH:mm:ss", d.getStart());
                    long endTime = DateUtils.strToTimeMillis("yyyy-MM-dd HH:mm:ss", d.getEnd());
                    if(endTime > startTime){
                        
                        ExclusionTime t = new ExclusionTime(startTime,endTime);
                        times.add(t);
                    }
                }
            } catch (Exception e) {
                log.error("参数转换异常！",e);
            }
            
        }
        return times;
    }
    
    
    public static void main(String[] args) {
        
//        List<ExclusionDate> exclusionDates = Lists.newArrayList(
//                new ExclusionDate("9","2019-08-05 19:30:00","2019-08-05 19:40:00"),
//                new ExclusionDate("0","00:00:00","23:59:59"),
//                new ExclusionDate("1","00:00:00","23:59:59"),
//                new ExclusionDate("2","00:00:00","23:59:59"),
//                new ExclusionDate("3","00:00:00","23:59:59"),
//                new ExclusionDate("4","00:00:00","23:59:59"),
//                new ExclusionDate("5","00:00:00","23:59:59"));
//        System.out.println(DateUtils.formatDate(TimerUtil.calculator(new Date(), 30,exclusionDates), "yyyy-MM-dd HH:mm:ss"));
    }

}
