package com.souche.orbit.sun.interceptor.repeat;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Maps;
import com.souche.bumblebee.trace.SoucheTraceUtil;
import com.souche.optimus.redis.RedisLock;
import com.souche.orbit.sun.utils.StringUtils;
import com.souche.sso.client2.AuthNHolder;
import java.io.PrintWriter;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

/**
 * @author SuperDaFu
 * @date 2019/3/29 上午9:44
 */
@Slf4j(topic = "repeatInterceptor")
public class RepeatInterceptor extends HandlerInterceptorAdapter {

    @Autowired
    private RedisLock redisLock;

    @Override
    public boolean preHandle(javax.servlet.http.HttpServletRequest request,
        javax.servlet.http.HttpServletResponse response, Object handler) throws Exception {
        final String userId = AuthNHolder.userId();
        if (StringUtils.isEmpty(userId)) {
            return true;
        }
        final String requestURI = request.getRequestURI();

        final String userAgent = parseUserAgent(request.getHeader("User-Agent"));

        String key = userId + requestURI + userAgent;
        request.setAttribute("repeatKey", key);
        log.info("Repeat Interceptor key:{}", key);
        if (redisLock.lock(key, SoucheTraceUtil.getTraceId(), 2)) {
            log.info("lock: {}", key);
            return true;
        } else {
            log.info("lock fail:{}", key);
            handleJson(request, response);
            return false;
        }
    }

    public static final Pattern rnUA = Pattern.compile("Platforms/.+\\s");

    private String parseUserAgent(String userAgent) {
        if (userAgent.startsWith("ReactNative")) {
            //RN请求
            final Matcher matcher = rnUA.matcher(userAgent);
            if (matcher.find()) {
                return matcher.group();
            }
        }
        return "";
    }

    private void handleJson(HttpServletRequest request, HttpServletResponse response) throws Exception {
        response.setHeader("Content-type", "application/json;charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        Map<String, Object> result = Maps.newHashMap();
        result.put("data", null);
        result.put("success", true);
        result.put("code", "200");
        result.put("msg", "skip");
        result.put("data", new Object());
        out.print(JSON.toJSONString(result));
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
        throws Exception {
        super.afterCompletion(request, response, handler, ex);
        final String repeatKey = String.valueOf(request.getAttribute("repeatKey"));
        if (StringUtils.isNotEmpty(repeatKey)) {
            redisLock.unlock(repeatKey, SoucheTraceUtil.getTraceId());
        }
    }
}
