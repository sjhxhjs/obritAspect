package com.souche.orbit.web.eunm;

import com.souche.orbit.sun.eunm.EnumMessage;
import com.souche.orbit.sun.eunm.EnumToDictionary;
import com.souche.orbit.sun.eunm.feature.EnumChangeName;
import com.souche.orbit.sun.eunm.feature.EnumVersion;
import lombok.AllArgsConstructor;

/**
 * @author SuperDaFu
 * @date 2019/2/21 上午10:15
 */
@AllArgsConstructor
@EnumToDictionary(key = "solar_start")
public enum SolarStarEnum implements EnumMessage, EnumVersion, EnumChangeName {
    SOLAR_STAR_SUN("sun", "太阳", "sun", StarTypeEnum.STAR_TYPE_STAR.getSignVersion());

    private String code;
    private String displayName;
    private String enName;
    private Integer version;

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String getChangeName(Integer version) {
        return null;
    }

    @Override
    public Integer getVersion() {
        return version;
    }
}
