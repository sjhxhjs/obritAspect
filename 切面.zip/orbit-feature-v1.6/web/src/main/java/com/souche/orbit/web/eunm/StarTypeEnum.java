package com.souche.orbit.web.eunm;

import com.souche.orbit.sun.eunm.EnumMessage;
import com.souche.orbit.sun.eunm.EnumToDictionary;
import lombok.AllArgsConstructor;

/**
 * @author SuperDaFu
 * @date 2019/2/21 上午10:07
 */
@AllArgsConstructor
@EnumToDictionary(key = "start_type")
public enum StarTypeEnum implements EnumMessage {
    STAR_TYPE_STAR("STAR", "恒星",                   0b1),
    STAR_TYPE_PLANET("PLANET", "行星",               0b10),
    STAR_TYPE_DWARF_PLANET("DWARF_PLANET", "矮行星", 0b100),
    STAR_TYPE_SATELLITE("SATELLITE", "卫星",         0b1000),
    STAR_TYPE_COMET("COMET", "彗星",                 0b10000),
    ;
    private String code;
    private String displayName;

    private int signVersion;

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getDisplayName() {
        return displayName;
    }

    public int getSignVersion() {
        return signVersion;
    }


}
