package com.souche.orbit.web.vo;

import com.souche.orbit.sun.dto.KVDTO;
import java.util.List;
import lombok.Data;

/**
 * @author SuperDaFu
 * @date 2019/2/21 上午10:25
 */
@Data
public class EnumCodeParamVO {

    private String packageName;
    private String className;
    private String key;
    private boolean userVersion;
    private boolean userChangeName;

    private List<KVDTO> otherFields;

    private String prefix;
    /**
     * 新建值的东西
     * prefix_[key]([code],[displayName]),
     */
    private List<List<EnumValueFieldObj>> values;

    public static class EnumValueFieldObj {

        /**
         * 值
         */
        String value;
        /**
         * 是否需要双引号
         */
        String needQuotation;
    }
}
