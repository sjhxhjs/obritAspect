package com.souche.orbit.web.eunm;

import com.souche.orbit.sun.eunm.EnumMessage;
import com.souche.orbit.sun.eunm.EnumToDictionary;
import lombok.AllArgsConstructor;

/**
 * @author SuperDaFu
 * @date 2019/2/21 上午10:22
 */
@AllArgsConstructor
@EnumToDictionary(key = "language")
public enum LanguageTypeEnum implements EnumMessage {

    ;

    private String code;
    private String displayName;

    @Override
    public String getCode() {
        return null;
    }

    @Override
    public String getDisplayName() {
        return null;
    }
}
