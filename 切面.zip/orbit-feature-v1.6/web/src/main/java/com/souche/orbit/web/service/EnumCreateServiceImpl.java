package com.souche.orbit.web.service;

import com.souche.orbit.sun.exception.ExceptionUtils;
import com.souche.orbit.web.vo.EnumCodeParamVO;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;

/**
 * @author SuperDaFu
 * @date 2019/2/21 上午10:24
 */
@Slf4j
@Service
public class EnumCreateServiceImpl implements EnumCreateService {

    @Autowired
    private FreeMarkerConfigurer freeMarkerConfigurer;

    @Override
    public String createEnum(EnumCodeParamVO enumCodeParamVO) {
        final freemarker.template.Configuration configuration = freeMarkerConfigurer.getConfiguration();
        try {
            final Template template = configuration.getTemplate("enum.ftl");
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            template.process(enumCodeParamVO, new OutputStreamWriter(byteArrayOutputStream));
            byteArrayOutputStream.flush();
            String result = new String(byteArrayOutputStream.toByteArray());
            byteArrayOutputStream.close();
            return result;
        } catch (IOException e) {
            log.error("获取模板失败", e);
            throw ExceptionUtils.fail("获取模板失败");
        } catch (TemplateException e) {
            log.error("输出模板失败", e);
            throw ExceptionUtils.fail("输出模板失败");
        }
    }
}
