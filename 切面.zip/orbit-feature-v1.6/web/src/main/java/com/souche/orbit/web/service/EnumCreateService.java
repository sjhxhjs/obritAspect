package com.souche.orbit.web.service;

import com.souche.orbit.web.vo.EnumCodeParamVO;

/**
 * @author SuperDaFu
 * @date 2019/2/21 上午10:24
 */
public interface EnumCreateService {

    String createEnum(EnumCodeParamVO enumCodeParamVO);
}
