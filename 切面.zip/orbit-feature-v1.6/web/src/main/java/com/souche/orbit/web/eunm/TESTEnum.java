package com.souche.orbit.web.eunm;

import com.souche.orbit.sun.eunm.EnumMessage;
import com.souche.orbit.sun.eunm.EnumToDictionary;
import com.souche.orbit.sun.eunm.feature.EnumChangeName;
import com.souche.orbit.sun.eunm.feature.EnumVersion;
import lombok.AllArgsConstructor;


/**
 * @author SuperDaFu
 * @date 2019/3/1 上午9:54
 */
@AllArgsConstructor
@EnumToDictionary(key = "")
public enum TESTEnum implements EnumMessage {
    ;
    private String code;
    private String displayName;

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getDisplayName() {
        return displayName;
    }
}

 