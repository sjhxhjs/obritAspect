package com.souche.orbit.web.json;

import com.google.common.collect.Lists;
import com.souche.optimus.core.annotation.Json;
import com.souche.optimus.core.annotation.Rest;
import com.souche.optimus.core.annotation.View;
import com.souche.optimus.core.web.OptimusRequestMethod;
import com.souche.orbit.web.service.EnumCreateService;
import com.souche.orbit.web.vo.EnumCodeParamVO;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author SuperDaFu
 * @date 2019/2/21 上午10:06
 */
@View(desc = "太阳系")
public class SolarAction {

    @Autowired
    private EnumCreateService enumCreateService;

    @Rest(value = "enumCodeCreate",desc = "新建枚举类",method = OptimusRequestMethod.POST)
    public List<String> enumCodeCreate(@Json(value = "enumCodeParamVo") List<EnumCodeParamVO> enumCodeParamVO) {
        List<String> result = Lists.newLinkedList();
        enumCodeParamVO.forEach(item->{
            result.add(enumCreateService.createEnum(item));
        });
        return result;
    }

}
